package com.example.myapplication

import PagerUiScreen
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.ExperimentalFoundationApi
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.pager.HorizontalPager
import androidx.compose.foundation.pager.PagerState
import androidx.compose.foundation.pager.rememberPagerState
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.FirstPage
import androidx.compose.material.icons.filled.LastPage
import androidx.compose.material.icons.filled.NavigateBefore
import androidx.compose.material.icons.filled.NavigateNext
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.tooling.preview.Preview
import androidx.compose.ui.unit.dp
import com.example.myapplication.ui.theme.MyApplicationTheme
import kotlinx.coroutines.launch

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent {
            MyApplicationTheme {
                ContentListingDemo()
            }
        }
    }

    @OptIn(ExperimentalMaterial3Api::class, ExperimentalFoundationApi::class)
    @Preview(
        showBackground = true, device = "id:pixel_7_pro", showSystemUi = true, name = "First View"
    )
    @Composable
    private fun ContentListingDemo() {
        Scaffold(
            topBar = {
                TopAppBar(title = { Text(stringResource(R.string.app_name)) })
            }, modifier = Modifier.fillMaxSize()
        ) { padding ->
            Column(
                Modifier
                    .fillMaxSize()
                    .padding(padding)
            ) {

                val pagerState = rememberPagerState()

                HorizontalPager(
                    pageCount = 10,
                    state = pagerState,
                    contentPadding = PaddingValues(horizontal = 32.dp),
                    pageSpacing = 4.dp,
                    modifier = Modifier
                        .fillMaxSize()
                        .weight(1f)
                ) { pageCount ->
                    PagerUiScreen(
                        page = pageCount, modifier = Modifier
                            .fillMaxSize()
                            .aspectRatio(1f)
                    )
                }

                ActionRow(pagerState, Modifier.align(Alignment.CenterHorizontally))


            }
        }
    }

    @OptIn(ExperimentalFoundationApi::class)
    @Composable
    fun ActionRow(pagerState: PagerState, align: Modifier, infiniteLoop: Boolean = false) {

        Row(align) {
            val scope = rememberCoroutineScope()

            IconButton(enabled = infiniteLoop.not() && pagerState.canScrollBackward, onClick = {
                scope.launch {
                    pagerState.animateScrollToPage(0)
                }
            }) {
                Icon(imageVector = Icons.Default.FirstPage, contentDescription = null)
            }


            IconButton(enabled = infiniteLoop || pagerState.canScrollBackward, onClick = {
                scope.launch {
                    pagerState.animateScrollToPage(pagerState.currentPage -1)
                }
            }) {
                Icon(imageVector = Icons.Default.NavigateBefore, contentDescription = null)
            }


            IconButton(enabled = infiniteLoop || pagerState.canScrollForward, onClick = {
                scope.launch {
                    pagerState.animateScrollToPage(pagerState.currentPage  + 1)
                }
            }) {
                Icon(imageVector = Icons.Default.NavigateNext, contentDescription = null)
            }



            IconButton(enabled = !infiniteLoop || pagerState.canScrollForward, onClick = {
                scope.launch {
                    pagerState.animateScrollToPage(9)
                }
            }) {
                Icon(imageVector = Icons.Default.LastPage, contentDescription = null)
            }


        }


    }

}
