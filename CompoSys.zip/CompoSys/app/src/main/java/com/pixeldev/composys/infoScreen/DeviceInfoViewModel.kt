package com.pixeldev.composys.infoScreen

import android.app.Application
import android.os.Environment
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.pixeldev.composys.utlis.Constant.MemoryInfo
import com.pixeldev.composys.utlis.Constant.getRamInfo
import com.pixeldev.composys.utlis.Constant.getStorageInfo
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.launch

class DeviceInfoViewModel(application: Application) : AndroidViewModel(application) {

    private val _ramInfo = MutableStateFlow<MemoryInfo?>(null)
    val ramInfo: StateFlow<MemoryInfo?> = _ramInfo

    private val _internalStorage = MutableStateFlow<MemoryInfo?>(null)
    val internalStorage: StateFlow<MemoryInfo?> = _internalStorage

    private val _externalStorage = MutableStateFlow<MemoryInfo?>(null)
    val externalStorage: StateFlow<MemoryInfo?> = _externalStorage

    init {
        startMonitoring()
    }

    private fun startMonitoring() {
        viewModelScope.launch {
            while (true) {
                val context = getApplication<Application>().applicationContext
                _ramInfo.value = getRamInfo(context)
                _internalStorage.value = getStorageInfo(Environment.getDataDirectory())
                if (Environment.getExternalStorageState() == Environment.MEDIA_MOUNTED) {
                    _externalStorage.value = getStorageInfo(Environment.getExternalStorageDirectory())
                } else {
                    _externalStorage.value = null
                }
                delay(2000) // Update every 2 seconds
            }
        }
    }
}
