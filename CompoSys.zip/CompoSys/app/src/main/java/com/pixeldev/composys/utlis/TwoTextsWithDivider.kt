package com.pixeldev.composys.utlis

import android.graphics.fonts.FontStyle
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.text.BasicText
import androidx.compose.material3.HorizontalDivider
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.Font
import androidx.compose.ui.text.font.FontFamily
import com.pixeldev.composys.ui.theme.Poppins

@Composable
fun TextsWithDivider(
    leftText: String,
    rightText: String,
    modifier: Modifier = Modifier
) {
    val customBoldStyle = TextStyle(
        fontSize = 16.sp,
        fontWeight = FontWeight.W700,   // you can choose W600, W700 etc instead of Bold keyword
        color = Color.Black,
        fontFamily = Poppins
    )

    val rightTextStyle = TextStyle(
        fontSize = 16.sp,
        color = Color.DarkGray,
        fontFamily = Poppins
    )


    Column(modifier = modifier.padding(horizontal = 16.dp)) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(vertical = 8.dp),
            horizontalArrangement = Arrangement.SpaceBetween
        ) {
            BasicText(
                text = leftText,
                style = customBoldStyle
            )
            BasicText(
                text = rightText,
                style = rightTextStyle
            )
        }
        HorizontalDivider(thickness = 1.dp, color = Color.Gray.copy(alpha = 0.5f))
    }
}
