package com.pixeldev.composys

import androidx.annotation.DrawableRes
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.Image
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.aspectRatio
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.navigation.NavHostController
import com.pixeldev.composys.utlis.CommonScaffold
import com.pixeldev.composys.utlis.CommonToolbar

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun MainInfoScreen(navController: NavHostController) {
    CommonScaffold(
        title = "H/W & S/W Info",
        onBackClick = { navController.popBackStack() }) { padding ->
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .padding(padding), // Makes the Box fill the entire available space
        ) {
            DeviceGrid(navController)
        }
    }
}


@Composable
fun DeviceGrid(navController: NavHostController) {
    LazyVerticalGrid(
        columns = GridCells.Fixed(3),
        modifier = Modifier
            .fillMaxSize()
            .padding(8.dp),
        contentPadding = PaddingValues(8.dp),
        horizontalArrangement = Arrangement.spacedBy(8.dp),
        verticalArrangement = Arrangement.spacedBy(8.dp)
    ) {
        item {
            DeviceGridItem("Device Info", R.drawable.phone, onClick = {
                navController.navigate(Screen.DeviceInfo.route)
            })
        }
        item {
            DeviceGridItem("OS Info", R.drawable.os, onClick = {
                navController.navigate(Screen.DeviceOSInfo.route)
            })
        }
        item {
            DeviceGridItem("Memory Info", R.drawable.memory, onClick = {
                navController.navigate(Screen.DeviceMemoryInfo.route)
            })
        }
        item {
            DeviceGridItem("Battery Info", R.drawable.charging, onClick = {
                navController.navigate(Screen.DeviceBatteryInfo.route)

            })
        }
        item {
            DeviceGridItem(
                "Thermal Info",
                R.drawable.thermodynamics,
                onClick = { navController.navigate(Screen.DeviceThermalInfo.route) })
        }
        item {
            DeviceGridItem(
                "Display Info",
                R.drawable.scan,
                onClick = { navController.navigate(Screen.DeviceDisplayInfo.route) })
        }
        item {
            DeviceGridItem(
                "Sensor Info",
                R.drawable.sensor,
                onClick = { navController.navigate(Screen.DeviceSensorInfo.route) })
        }
        item {
            DeviceGridItem(
                "Processor Info",
                R.drawable.cpu,
                onClick = { navController.navigate(Screen.DeviceProccerInfo.route) })
        }
        item {
            DeviceGridItem(
                "Feature Info",
                R.drawable.features,
                onClick = { navController.navigate(Screen.DeviceFeaturesInfo.route) })
        }
        item {
            DeviceGridItem(
                "Sim Info",
                R.drawable.sim,
                onClick = { navController.navigate(Screen.DeviceSimInfo.route) })
        }

    }
}


@Composable
fun DeviceGridItem(
    name: String,
    @DrawableRes imageRes: Int, onClick: () -> Unit = {}
) {
    Card(
        onClick = onClick,
        modifier = Modifier
            .fillMaxWidth()
            .aspectRatio(1f),
        colors = CardDefaults.cardColors(containerColor = Color(0xffB7DFF5).copy(alpha = 0.1f)),
        border = BorderStroke(2.dp, Color(0xffB7DFF5).copy(alpha = 0.7f)),
        shape = RoundedCornerShape(12.dp)
    ) {
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(12.dp),
            horizontalAlignment = Alignment.CenterHorizontally,
            verticalArrangement = Arrangement.Center
        ) {
            Image(
                painter = painterResource(id = imageRes),
                contentDescription = name,
                modifier = Modifier
                    .size(48.dp)
                    .padding(bottom = 8.dp),
                contentScale = ContentScale.Fit
            )
            Text(
                text = name,
                style = MaterialTheme.typography.bodyMedium,
                textAlign = TextAlign.Center
            )
        }
    }

}

