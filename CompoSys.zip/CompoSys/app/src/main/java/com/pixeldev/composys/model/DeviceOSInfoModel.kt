package com.pixeldev.composys.model

data class DeviceOSInfoModel(
    val model: String,
    val androidVersion: String,
    val sdkVersion: String,
    val codeName: String,
    val incrementalVersion: String,
    val securityPatch: String,
    val baseOS: String,
    val fingerprint: String,
    val buildId: String,
    val kernelVersion: String,
    val androidVersionName: String,
)