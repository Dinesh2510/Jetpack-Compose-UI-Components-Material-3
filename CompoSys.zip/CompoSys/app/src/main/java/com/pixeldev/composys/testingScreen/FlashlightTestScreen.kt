package com.pixeldev.composys.testingScreen
import android.content.Context
import android.hardware.camera2.CameraCharacteristics
import android.hardware.camera2.CameraManager
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.FlashOff
import androidx.compose.material.icons.filled.FlashOn
import androidx.compose.material.icons.filled.FlashlightOff
import androidx.compose.material.icons.filled.FlashlightOn
import androidx.compose.material3.Button
import androidx.compose.material3.Icon
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.navigation.NavController
import com.pixeldev.composys.utlis.CommonScaffold

@Composable
fun FlashlightTestScreen(navController: NavController) {
    val context = LocalContext.current
    val flashlightController = remember { FlashlightController(context) }

    var isFlashOn by remember { mutableStateOf(false) }
    var hasFlash by remember { mutableStateOf(false) }

    LaunchedEffect(Unit) {
        hasFlash = flashlightController.hasFlash()
    }

    DisposableEffect(isFlashOn) {
        flashlightController.toggleFlashlight(isFlashOn)
        onDispose {
            flashlightController.toggleFlashlight(false) // Always turn off when leaving
        }
    }
    CommonScaffold(
        title = "FlashLight Testing",
        onBackClick = { navController!!.popBackStack() }) { padding ->

    Column(
        modifier = Modifier
            .fillMaxSize()
            .padding(24.dp),
        verticalArrangement = Arrangement.spacedBy(24.dp, Alignment.CenterVertically),
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        Text("Flashlight Test", fontSize = 22.sp, fontWeight = FontWeight.Bold)

        if (!hasFlash) {
            Text("Your device does not support flashlight.", color = Color.Red)
        } else {
            Icon(
                imageVector = if (isFlashOn) Icons.Default.FlashlightOn else Icons.Default.FlashlightOff,
                contentDescription = "Flash Icon",
                tint = if (isFlashOn) Color(0xFFFFC400) else Color.Gray,
                modifier = Modifier.size(100.dp)
            )

            Button(onClick = { isFlashOn = !isFlashOn }) {
                Text(if (isFlashOn) "Turn Off" else "Turn On")
            }
        }

        Button(onClick = { navController.popBackStack() }) {
            Text("Back")
        }
    }
}}
class FlashlightController(private val context: Context) {
    private val cameraManager = context.getSystemService(Context.CAMERA_SERVICE) as CameraManager
    private val cameraId = cameraManager.cameraIdList.firstOrNull {
        cameraManager.getCameraCharacteristics(it)
            .get(CameraCharacteristics.FLASH_INFO_AVAILABLE) == true
    }

    fun toggleFlashlight(isOn: Boolean) {
        cameraId?.let {
            cameraManager.setTorchMode(it, isOn)
        }
    }

    fun hasFlash(): Boolean {
        return cameraId != null
    }
}
