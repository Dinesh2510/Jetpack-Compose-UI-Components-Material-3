package com.pixeldev.composys.infoScreen

import android.app.ActivityManager
import android.content.Context
import android.content.Intent
import android.content.pm.ApplicationInfo
import android.content.pm.PackageManager
import android.graphics.drawable.Drawable
import android.os.Build
import android.provider.Settings
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.MoreVert
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.DropdownMenu
import androidx.compose.material3.DropdownMenuItem
import androidx.compose.material3.FilterChip
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.core.graphics.drawable.toBitmap
import androidx.navigation.NavHostController
import com.pixeldev.composys.utlis.CommonScaffold
import com.pixeldev.composys.utlis.Constant.getRamInfo
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.delay
import kotlinx.coroutines.withContext
import java.io.File
import androidx.core.net.toUri
import com.pixeldev.composys.R
import com.pixeldev.composys.Screen
import com.pixeldev.composys.utlis.Constant.formatBytes
import com.pixeldev.composys.utlis.RotatingFan


@Composable
fun DeviceProccerScreen(navController: NavHostController) {
    CommonScaffold(
        title = "Processor Info",
        onBackClick = { navController.popBackStack() }) {
        val context = LocalContext.current
        Column(modifier = Modifier.padding(it)) {
            DashboardTopSection {
                navController.navigate(Screen.AppListT.route)
            }
            Column(modifier = Modifier.padding(16.dp)) {
                CpuDetailsSection()
            }
        }
    }
}


fun getCpuCores(): Int = Runtime.getRuntime().availableProcessors()

fun getSupportedAbis(): List<String> = Build.SUPPORTED_ABIS.toList()


/*==============================================================*/


data class AppInfo(
    val name: String,
    val packageName: String,
    val versionName: String,
    val appType: String,
    val icon: Drawable,
    val appSizeMB: String,
    val permissions: List<String>,
)

fun getAppType(appInfo: ApplicationInfo): String {
    return when {
        appInfo.sourceDir.startsWith("/system") ||
                appInfo.sourceDir.startsWith("/product") -> "System"

        appInfo.flags and ApplicationInfo.FLAG_UPDATED_SYSTEM_APP != 0 -> "Updated System"

        else -> "Third-party"
    }
}

fun getAppSize(context: Context, packageName: String): String {
    return try {
        val file = File(
            context.packageManager.getPackageInfo(packageName, 0)
                .applicationInfo!!.sourceDir
        )
        val sizeInMB = file.length() / (1024.0 * 1024.0)
        "%.2f MB".format(sizeInMB)
    } catch (e: Exception) {
        "N/A"
    }
}

fun getInstalledApps(context: Context): List<AppInfo> {
    val pm = context.packageManager

    // Use correct flags depending on Android version
    val packages = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
        pm.getInstalledPackages(
            PackageManager.PackageInfoFlags.of(PackageManager.GET_PERMISSIONS.toLong())
        )
    } else {
        @Suppress("DEPRECATION")
        pm.getInstalledPackages(PackageManager.GET_PERMISSIONS)
    }

    return packages.map { pkg ->
        val type = getAppType(pkg.applicationInfo!!)
        val size = getAppSize(context, pkg.packageName)


        AppInfo(
            name = pkg.applicationInfo!!.loadLabel(pm).toString(),
            packageName = pkg.packageName,
            versionName = pkg.versionName ?: "N/A",
            appType = type,
            icon = pkg.applicationInfo!!.loadIcon(pm),
            appSizeMB = size,
            // Only requested permission names
            permissions = pkg.requestedPermissions?.toList() ?: emptyList()
        )
    }
}

fun getRamInfo(context: Context): Pair<Long, Long> {
    val activityManager = context.getSystemService(Context.ACTIVITY_SERVICE) as ActivityManager
    val memInfo = ActivityManager.MemoryInfo()
    activityManager.getMemoryInfo(memInfo)
    val total = memInfo.totalMem / (1024 * 1024)
    val used = (memInfo.totalMem - memInfo.availMem) / (1024 * 1024)
    return Pair(total, used)
}

fun getCpuArch(): String = System.getProperty("os.arch") ?: "Unknown"

fun readCPUInfo(): String {
    return try {
        File("/proc/cpuinfo").readText()
    } catch (e: Exception) {
        "Could not read CPU info"
    }
}

fun getSystemAppInfo(context: Context): Pair<Int, String> {
    val pm = context.packageManager
    val apps = pm.getInstalledPackages(0)
    val systemApps = apps.filter {
        (it.applicationInfo!!.flags and ApplicationInfo.FLAG_SYSTEM) != 0
    }

    val totalSize = systemApps.sumOf {
        try {
            File(it.applicationInfo!!.sourceDir).length()
        } catch (e: Exception) {
            0L
        }
    }

    val sizeMB = "%.2f MB".format(totalSize / (1024f * 1024f))
    return Pair(systemApps.size, sizeMB)
}


@Composable
fun DashboardTopSection(
    onSystemAppClick: () -> Unit
) {
    val context = LocalContext.current
    var speed by remember { mutableStateOf(300f) } // degrees/sec

    val (systemAppCount, systemAppSize) = remember { getSystemAppInfo(context) }
    val (totalRam, usedRam) = remember { getRamInfo(context) }
    val cpuArch = remember { getCpuArch() }
    val coreCount = getCpuCores()

    Row(
        modifier = Modifier
            .fillMaxWidth()
            .padding(16.dp),
        horizontalArrangement = Arrangement.SpaceBetween,
        verticalAlignment = Alignment.CenterVertically
    ) {
        // Left: System App Info
        Column(
            modifier = Modifier
                .clickable { onSystemAppClick() }
                .padding(8.dp),
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            Text("System Apps", fontWeight = FontWeight.Bold)
            Text("$systemAppCount apps",fontSize = 12.sp)
            Text("Size: $systemAppSize", fontSize = 12.sp)
        }

        // Center: Fan + CPU Info
        Column(
            horizontalAlignment = Alignment.CenterHorizontally,
            verticalArrangement = Arrangement.Center
        ) {
            Box(contentAlignment = Alignment.Center) {
                CircularProgressIndicator(
                    progress = 1f,
                    modifier = Modifier.size(100.dp),
                    strokeWidth = 4.dp
                )
                Column(
                    horizontalAlignment = Alignment.CenterHorizontally,
                    modifier = Modifier.size(60.dp)
                ) {
                    RotatingFan(R.drawable.fan, speed)
                }
            }

            Spacer(modifier = Modifier.height(8.dp))

            // CPU Info Below Fan
            Column(horizontalAlignment = Alignment.CenterHorizontally) {
                Text("CPU", fontWeight = FontWeight.Bold)
                // Text(cpuArch, fontSize = 12.sp)
                Text("$coreCount Cores",fontSize = 12.sp)
            }
        }

        // Right: RAM Info
        Column(
            modifier = Modifier.padding(8.dp),
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            Text("RAM", fontWeight = FontWeight.Bold)
            Text("Total: ${formatBytes(totalRam)}",fontSize = 12.sp)
            Text("Used: ${formatBytes(usedRam)}", fontSize = 12.sp)
        }
    }
}


@Composable
fun CpuDetailsSection() {
    val cpuInfo = remember { readCPUInfo() }
    val lines = cpuInfo.split("\n").filter { it.isNotBlank() }
    val arch = getCpuArch()
    LazyColumn(
        modifier = Modifier
            .fillMaxWidth()
            .padding(8.dp)
    ) {
        items(lines.size) { line ->
            val parts = lines[line].split(":")
            if (parts.size == 2) {
                Row(
                    Modifier
                        .fillMaxWidth()
                        .padding(vertical = 8.dp),
                    horizontalArrangement = Arrangement.SpaceBetween
                ) {
                    Text(parts[0].trim(), fontWeight = FontWeight.SemiBold)
                    Text(parts[1].trim())
                }
                HorizontalDivider(thickness = 1.dp, color = Color.Gray.copy(alpha = 0.5f))
            }
        }
    }
}

/**====================================App Listing Code Starts==========================*/

@Composable
fun AppListContent(apps: List<AppInfo>) {
    // Store the selected app (null = no dialog)
    var selectedApp by remember { mutableStateOf<AppInfo?>(null) }
    var context = LocalContext.current
    LazyColumn(
        modifier = Modifier
            .fillMaxSize()
            .padding(16.dp)
    ) {

        items(apps.size) { index ->
            val app = apps[index]

            AppInfoItem(
                icon = app.icon,
                title = app.name,
                packageName = app.packageName,
                size = app.appSizeMB,
                appType = app.appType,
                onExtract = { /* TODO: Extract APK */ },
                onAppInfo = {
                    val intent = Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS).apply {
                        data = "package:${app.packageName}".toUri()
                        addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                    }
                    context.startActivity(intent)
                },
                onSaveIcon = { /* TODO: Save icon */ },
                onViewOnPlayStore = {
                    val intent = Intent(Intent.ACTION_VIEW).apply {
                        data =
                            "https://play.google.com/store/apps/details?id=${app.packageName}".toUri()
                        addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                    }
                    context.startActivity(intent)
                },
                onShare = {
                    val intent = Intent(Intent.ACTION_SEND).apply {
                        type = "text/plain"
                        putExtra(
                            Intent.EXTRA_TEXT,
                            "Check out this app: ${app.name}\nhttps://play.google.com/store/apps/details?id=${app.packageName}"
                        )
                        addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                    }
                    context.startActivity(Intent.createChooser(intent, "Share via"))
                },
                onClickCard = { selectedApp = app }
            )
            Spacer(modifier = Modifier.height(8.dp))
        }
    }

    // Show dialog if app is selected
    selectedApp?.let { app ->
        AppDetailDialog(
            app = app,
            onDismiss = { selectedApp = null },
            onExtract = { /* TODO: Extract app */ }
        )
    }
}


@Composable
fun AppDetailDialog(
    app: AppInfo,
    onDismiss: () -> Unit,
    onExtract: () -> Unit
) {
    val imageBitmap = remember(app.icon) {
        app.icon.toBitmap().asImageBitmap()
    }
    AlertDialog(
        onDismissRequest = { onDismiss() },
        title = {
            Row(verticalAlignment = Alignment.CenterVertically) {

                Image(
                    bitmap = imageBitmap,
                    contentDescription = null,
                    modifier = Modifier.size(32.dp)
                )

                Spacer(modifier = Modifier.width(8.dp))
                Text(text = app.name, fontWeight = FontWeight.Bold, fontSize = 18.sp)
            }
        },
        text = {
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .heightIn(max = 300.dp) // limit dialog height
                    .verticalScroll(rememberScrollState())
            ) {
                Text("Package Name: ${app.packageName}")
                Text("Version: ${app.versionName}")
                Text("Size: ${app.appSizeMB}")

                Spacer(modifier = Modifier.height(8.dp))
                Text("Permissions:", fontWeight = FontWeight.Bold)
                app.permissions.forEach {
                    Text(it, fontSize = 12.sp, color = Color.Gray)
                }
            }
        },
        confirmButton = {
            TextButton(onClick = { onExtract() }) {
                Text("EXTRACT")
            }
        },
        dismissButton = {
            TextButton(onClick = { onDismiss() }) {
                Text("CANCEL")
            }
        }
    )
}

enum class AppFilterType(val label: String) {
    ALL("All"),
    SYSTEM("System"),
    THIRD_PARTY("Third-party"),
    UPDATED_SYSTEM("Updated System")
}

@Composable
fun SystemAppLoaderScreen(navController: NavHostController) {
    val context = LocalContext.current
    var isLoading by remember { mutableStateOf(true) }
    var allApps by remember { mutableStateOf<List<AppInfo>>(emptyList()) }
    var selectedFilter by remember { mutableStateOf(AppFilterType.ALL) }

    LaunchedEffect(true) {
        withContext(Dispatchers.IO) {
            allApps = getInstalledApps(context) // includes all types
            delay(500)
            isLoading = false
        }
    }
    CommonScaffold(
        title = "Apps Listing",
        onBackClick = { navController.popBackStack() }) {
        if (isLoading) {
            Box(modifier = Modifier.fillMaxSize().padding(it), contentAlignment = Alignment.Center) {
                CircularProgressIndicator()
            }
        } else {
            Column(modifier = Modifier.fillMaxSize().padding(it)) {

                // 🔍 Filter Row
                FilterChips(selected = selectedFilter) {
                    selectedFilter = it
                }
                // 🔎 Filtered list
                val filteredApps = when (selectedFilter) {
                    AppFilterType.ALL -> allApps
                    AppFilterType.SYSTEM -> allApps.filter { it.appType == "System" }
                    AppFilterType.THIRD_PARTY -> allApps.filter { it.appType == "Third-party" }
                    AppFilterType.UPDATED_SYSTEM -> allApps.filter { it.appType == "Updated System" }
                }
                AppListContent(filteredApps)
            }
        }
    }
}

@Composable
fun AppInfoItem(
    icon: Drawable,
    title: String,
    packageName: String,
    size: String,
    appType: String,
    onClickCard: () -> Unit,
    onExtract: () -> Unit,
    onAppInfo: () -> Unit,
    onSaveIcon: () -> Unit,
    onViewOnPlayStore: () -> Unit,
    onShare: () -> Unit,
) {
    val imageBitmap = remember(icon) {
        icon.toBitmap().asImageBitmap()
    }
    var expanded by remember { mutableStateOf(false) }

    Card(
        modifier = Modifier
            .fillMaxWidth(),
        colors = CardDefaults.cardColors(Color.White),
        elevation = CardDefaults.cardElevation(8.dp),
        shape = RoundedCornerShape(8.dp),
    ) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(0.dp)
                /*.background(Color.White, RoundedCornerShape(6.dp))*/
                /*  .border(1.dp, Color.LightGray, RoundedCornerShape(6.dp))*/
                .clickable { onClickCard() }
                .padding(12.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Image(bitmap = imageBitmap, contentDescription = null, modifier = Modifier.size(48.dp))

            Spacer(modifier = Modifier.width(12.dp))

            // Texts (title + package name + size)
            Column(
                modifier = Modifier.weight(1f)
            ) {
                Text(
                    text = title,
                    fontWeight = FontWeight.Bold,
                    fontSize = 16.sp,
                    maxLines = 1,
                    overflow = TextOverflow.Ellipsis
                )
                Text(text = packageName, color = Color.Gray, fontSize = 12.sp)
                Text(text = size, color = Color.Gray, fontSize = 12.sp)
                AppTypeTag(appType)
            }

            // Menu Button (3 dots)
            IconButton(onClick = { expanded = true }) {
                Icon(
                    imageVector = Icons.Default.MoreVert,
                    contentDescription = "Menu"
                )
            }

            Box {

                DropdownMenu(
                    expanded = expanded,
                    onDismissRequest = { expanded = false }
                ) {
                    DropdownMenuItem(
                        text = { Text("Extract") },
                        onClick = {
                            expanded = false
                            onExtract()
                        }
                    )
                    DropdownMenuItem(
                        text = { Text("App Info") },
                        onClick = {
                            expanded = false
                            onAppInfo()
                        }
                    )
                    DropdownMenuItem(
                        text = { Text("Save Icon") },
                        onClick = {
                            expanded = false
                            onSaveIcon()
                        }
                    )
                    DropdownMenuItem(
                        text = { Text("View on Play Store") },
                        onClick = {
                            expanded = false
                            onViewOnPlayStore()
                        }
                    )
                    DropdownMenuItem(
                        text = { Text("Share") },
                        onClick = {
                            expanded = false
                            onShare()
                        }
                    )
                }
            }
        }
    }

}


@Composable
fun FilterChips(
    selected: AppFilterType,
    onSelectedChanged: (AppFilterType) -> Unit
) {
    val filterOptions = AppFilterType.values()

    Row(
        modifier = Modifier
            .horizontalScroll(rememberScrollState())
            .padding(8.dp)
    ) {
        filterOptions.forEach { filter ->
            val selectedState = selected == filter
            FilterChip(
                selected = selectedState,
                onClick = { onSelectedChanged(filter) },
                label = {
                    Text(filter.label)
                },
                modifier = Modifier.padding(horizontal = 4.dp)
            )
        }
    }
}

@Composable
fun AppCard(app: AppInfo) {
    val imageBitmap = remember(app.icon) {
        app.icon.toBitmap().asImageBitmap()
    }

    Card(
        modifier = Modifier
            .fillMaxWidth()
            .padding(vertical = 8.dp),
        colors = CardDefaults.cardColors(Color.White),
        elevation = CardDefaults.cardElevation(4.dp)
    ) {
        Row(
            modifier = Modifier.padding(16.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Image(bitmap = imageBitmap, contentDescription = null, modifier = Modifier.size(48.dp))
            Spacer(modifier = Modifier.width(8.dp))
            Column(modifier = Modifier.weight(1f)) {
                Text(app.name, fontWeight = FontWeight.Bold)
                Text("${app.packageName}", fontSize = 10.sp)
                Text("Version: ${app.versionName}", fontSize = 10.sp)
                Text("Size: ${app.appSizeMB}", fontSize = 10.sp)
                AppTypeTag(app.appType)
            }
        }
    }
}


@Composable
fun AppTypeTag(type: String) {
    val backgroundColor = when (type) {
        "System" -> Color(0xFF1976D2)
        "Updated System" -> Color(0xFFFFA000)
        else -> Color(0xFF388E3C)
    }

    Box(
        modifier = Modifier
            .background(backgroundColor, shape = RoundedCornerShape(8.dp))
            .padding(horizontal = 8.dp, vertical = 4.dp)
    ) {
        Text(text = type, color = Color.White, fontSize = 12.sp)
    }
}
