package com.pixeldev.composys.utlis

import android.Manifest
import android.content.Context
import android.content.pm.PackageManager
import android.os.Build
import android.util.Log
import androidx.core.content.ContextCompat
import kotlin.collections.iterator

class PermissionManager {

    companion object {
        const val TAG = "PermissionManager"

        fun getPermissions(): List<String> {
            val permissions = mutableListOf(
                Manifest.permission.CAMERA,
                Manifest.permission.READ_PHONE_STATE,
                Manifest.permission.READ_PHONE_NUMBERS,
                Manifest.permission.READ_SMS
            )

            if (Build.VERSION.SDK_INT < Build.VERSION_CODES.Q) {
                permissions.add(Manifest.permission.WRITE_EXTERNAL_STORAGE)
                permissions.add(Manifest.permission.READ_EXTERNAL_STORAGE)
            }

            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
                permissions.add(Manifest.permission.READ_MEDIA_AUDIO)
            } else {
                permissions.add(Manifest.permission.READ_EXTERNAL_STORAGE)
            }

            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S) {
                permissions.add(Manifest.permission.BLUETOOTH_SCAN)
                permissions.add(Manifest.permission.BLUETOOTH_CONNECT)
            }

            return permissions
        }

        fun areAllPermissionsGranted(context: Context): Boolean {
            return getPermissions().all {
                ContextCompat.checkSelfPermission(context, it) == PackageManager.PERMISSION_GRANTED
            }
        }

        fun logPermissionsResult(results: Map<String, Boolean>) {
            for ((perm, granted) in results) {
                if (granted) {
                    Log.i(TAG, "Permission granted: $perm")
                } else {
                    Log.w(TAG, "Permission denied: $perm")
                }
            }
        }
    }
}