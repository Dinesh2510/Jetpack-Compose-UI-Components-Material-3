package com.pixeldev.composys.testingScreen
import android.content.Context
import android.hardware.Sensor
import android.hardware.SensorEvent
import android.hardware.SensorEventListener
import android.hardware.SensorManager
import android.media.AudioFormat
import android.media.AudioRecord
import android.media.MediaRecorder
import android.os.Build
import android.os.VibrationEffect
import android.os.Vibrator
import androidx.compose.foundation.background
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.offset
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.material3.Button
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.IntOffset
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.navigation.NavController
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import kotlin.math.abs






import androidx.compose.foundation.Canvas
import androidx.compose.foundation.layout.Row
import com.pixeldev.composys.utlis.CommonScaffold


@Composable
fun TouchTestScreen(navController: NavController) {
    var touchPoints by remember { mutableStateOf(listOf<Offset>()) }
    CommonScaffold(
        title = "Touch sensor Testing",
        onBackClick = { navController!!.popBackStack() }) { padding ->

    Box(
        modifier = Modifier.padding(padding)
            .fillMaxSize()
            .background(Color.White)
            .pointerInput(Unit) {
                detectTapGestures { offset ->
                    touchPoints = touchPoints + offset
                }
            }
    ) {
        // Draw circles for each touch point
        touchPoints.forEach { point ->
            Canvas(
                modifier = Modifier
                    .size(30.dp)
                    .offset { IntOffset(point.x.toInt() - 15, point.y.toInt() - 15) }
            ) {
                drawCircle(
                    color = Color.Red,
                    radius = size.minDimension / 2f
                )
            }
        }

        // UI buttons on top
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .padding(16.dp)
                .align(Alignment.TopCenter),
            verticalArrangement = Arrangement.spacedBy(8.dp),
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            Text("Touch Test - Tap anywhere", style = MaterialTheme.typography.headlineSmall)

            Row(horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                Button(onClick = { touchPoints = emptyList() }) {
                    Text("Clear")
                }
                Button(onClick = { navController.popBackStack() }) {
                    Text("Back")
                }
            }
        }
    }
}}
/*
@Composable
fun SpeakerTestScreen(navController: NavController) {
    val context = LocalContext.current
    var isPlaying by remember { mutableStateOf(false) }
    val mediaPlayer = remember {
        MediaPlayer.create(context, R.raw.mysound) // put a raw resource named test_sound.mp3
    }

    DisposableEffect(isPlaying) {
        if (isPlaying) mediaPlayer.start() else mediaPlayer.pause()
        onDispose { mediaPlayer.release() }
    }

    Column(
        modifier = Modifier.fillMaxSize().padding(24.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp),
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        Text("Speaker Test", fontSize = 22.sp, fontWeight = FontWeight.Bold)
        Button(onClick = { isPlaying = !isPlaying }) {
            Text(if (isPlaying) "Stop Sound" else "Play Test Sound")
        }
        Button(onClick = { navController.popBackStack() }) {
            Text("Back")
        }
    }
}*/