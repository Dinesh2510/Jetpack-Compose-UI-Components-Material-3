package com.pixeldev.composys.infoScreen

import android.content.Intent
import android.os.Build
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.material3.Button
import androidx.compose.material3.Scaffold
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.dp
import androidx.navigation.NavHostController
import com.pixeldev.composys.utlis.Constant.getAndroidVersionName
import com.pixeldev.composys.utlis.Constant.getBuildTime
import android.provider.Settings
import android.widget.Toast
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.material3.Text
import androidx.compose.ui.Alignment
import com.pixeldev.composys.utlis.CommonToolbar
import com.pixeldev.composys.R
import com.pixeldev.composys.model.DeviceOSInfoModel
import com.pixeldev.composys.utlis.CommonScaffold
import com.pixeldev.composys.utlis.Constant.isDeviceRooted
import com.pixeldev.composys.utlis.TextsWithDivider

@Composable
fun DeviceOSInfoScreen(navController: NavHostController) {
    val context = LocalContext.current
    val info = getDeviceOSInfo()

    CommonScaffold(
        title = "Device OS Info",
        onBackClick = { navController.popBackStack() }) {
        LazyColumn(
            modifier = Modifier
                .padding(it)
                .fillMaxSize()
                .padding(16.dp)
        ) {
            item {
                ImageCard(
                    imageRes = R.drawable.android,  // Replace with your drawable resource
                    title = info.androidVersionName,
                    subtitle = "Android ${info.sdkVersion}"
                )
            }
            item { TextsWithDivider("Android Version", info.androidVersion) }
            item { TextsWithDivider("Version Name", info.androidVersionName) }
            item { TextsWithDivider("SDK Version", info.sdkVersion) }
            item { TextsWithDivider("Model", info.model) }
            item { TextsWithDivider("Code Name", info.codeName) }
            item { TextsWithDivider("Product", info.incrementalVersion) }
            item { TextsWithDivider("Security Patch", info.securityPatch) }
            item { TextsWithDivider("Build Time", getBuildTime()) }
            item { TextsWithDivider("FingerPrint", info.fingerprint) }
            item { TextsWithDivider("Build ID", info.buildId) }
            item { TextsWithDivider("Kernel Version", info.kernelVersion) }
            if (isDeviceRooted()) {
                item { TextsWithDivider("Device Rooted", "Rooted") }
            } else {
                item { TextsWithDivider("Device Rooted", " Not Rooted") }
            }


            item {
                Column(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(top = 24.dp),  // padding from top
                    horizontalAlignment = Alignment.CenterHorizontally  // center children horizontally
                ) {
                    Button(onClick = {
                        val action = if (Build.VERSION.SDK_INT >= 28) {
                            Settings.ACTION_SETTINGS
                        } else {
                            "android.settings.SYSTEM_UPDATE_SETTINGS" // fallback string
                        }
                        val intent = Intent(action)
                        if (intent.resolveActivity(context.packageManager) != null) {
                            context.startActivity(intent)
                        } else {
                            Toast.makeText(
                                context,
                                "System update settings not available",
                                Toast.LENGTH_SHORT
                            ).show()
                        }
                    }) {
                        Text(text = "Check for System Update")
                    }
                }
            }
        }
    }
}

fun getDeviceOSInfo(): DeviceOSInfoModel {
    return DeviceOSInfoModel(
        model = Build.MODEL,
        androidVersion = Build.VERSION.RELEASE,
        sdkVersion = Build.VERSION.SDK_INT.toString(),
        codeName = Build.VERSION.CODENAME,
        incrementalVersion = Build.VERSION.INCREMENTAL,
        securityPatch = Build.VERSION.SECURITY_PATCH ?: "N/A",
        baseOS = Build.VERSION.BASE_OS ?: "N/A",
        fingerprint = Build.BRAND,
        buildId = Build.ID,
        kernelVersion = System.getProperty("os.version") ?: "N/A",
        androidVersionName = getAndroidVersionName(Build.VERSION.SDK_INT),  // here!

    )
}
