package com.pixeldev.composys

import android.content.Intent
import androidx.annotation.DrawableRes
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.Image
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.aspectRatio
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.navigation.NavHostController
import com.pixeldev.composys.testingScreen.BioMetricMainActivity
import com.pixeldev.composys.utlis.CommonScaffold

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun MainTestScreen(navController: NavHostController) {

    CommonScaffold(
        title = "Device Testing",
        onBackClick = { navController!!.popBackStack() }) { padding ->
        DeviceTestGrid(navController, padding)

    }

}


@Composable
fun DeviceTestGrid(navController: NavHostController, padding: PaddingValues) {
    val context = LocalContext.current
    LazyVerticalGrid(
        columns = GridCells.Fixed(3),
        modifier = Modifier
            .fillMaxSize()
            .padding(padding)
            .padding(8.dp),
        contentPadding = PaddingValues(8.dp),
        horizontalArrangement = Arrangement.spacedBy(8.dp),
        verticalArrangement = Arrangement.spacedBy(8.dp)
    ) {
        item {
            DeviceGridItemTest("Display Test", R.drawable.smartphone, onClick = {
                navController.navigate(Screen.DisplayTest.route)
            })
        }
        item {
            DeviceGridItemTest("FlashLight Test", R.drawable.torch, onClick = {
                navController.navigate(Screen.FlashLightTest.route)
            })
        }
        item {
            DeviceGridItemTest("Volume Test", R.drawable.volume, onClick = {
                navController.navigate(Screen.Volume.route)
            })
        }
        item {
            DeviceGridItemTest("WiFi Scanner", R.drawable.wifi, onClick = {
                navController.navigate(Screen.WifiScanner.route)
            })
        }
        item {
            DeviceGridItemTest("Touch Test", R.drawable.touch, onClick = {
                navController.navigate(Screen.TouchTest.route)
            })
        }
        item {
            DeviceGridItemTest("Proximity Sensor", R.drawable.gossip, onClick = {
                navController.navigate(Screen.Proximity.route)
            })
        }
        item {
            DeviceGridItemTest("Light Sensor", R.drawable.lightbulb, onClick = {
                navController.navigate(Screen.LightSensor.route)
            })
        }
        item {
            DeviceGridItemTest("Bluetooth Test", R.drawable.bluetooth, onClick = {
                navController.navigate(Screen.Bluetooth.route)
            })
        }
        item {
            DeviceGridItemTest("Biometric Test", R.drawable.security, onClick = {
                val intent = Intent(context, BioMetricMainActivity::class.java)
                context.startActivity(intent)
            })
        }

        item {
            DeviceGridItemTest("Microphone Test", R.drawable.microphone, onClick = {
                navController.navigate(Screen.MicroPhoneT.route)
            })
        }
        item {
            DeviceGridItemTest("Sensor Test", R.drawable.sensor, onClick = {
                navController.navigate(Screen.SensorT.route)
            })
        }
        item {
            DeviceGridItemTest("Vibrate Test", R.drawable.vibrate, onClick = {
                navController.navigate(Screen.VibrateT.route)
            })
        }
        item {
            DeviceGridItemTest("Speed Test", R.drawable.speed, onClick = {
                navController.navigate(Screen.SpeedTestT.route)
            })
        }

    }

}

@Composable
fun DeviceGridItemTest(
    name: String,
    @DrawableRes imageRes: Int, onClick: () -> Unit = {}
) {
    Card(
        onClick = onClick,
        modifier = Modifier
            .fillMaxWidth()
            .aspectRatio(1f),
        colors = CardDefaults.cardColors(containerColor = Color(0xffD3B0E0).copy(alpha = 0.1f)),
        border = BorderStroke(2.dp, Color(0xffD3B0E0).copy(alpha = 0.7f)),
        shape = RoundedCornerShape(12.dp)
    ) {
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(12.dp),
            horizontalAlignment = Alignment.CenterHorizontally,
            verticalArrangement = Arrangement.Center
        ) {
            Image(
                painter = painterResource(id = imageRes),
                contentDescription = name,
                modifier = Modifier
                    .size(48.dp)
                    .padding(bottom = 8.dp),
                contentScale = ContentScale.Fit
            )
            Text(
                text = name,
                style = MaterialTheme.typography.bodyMedium,
                textAlign = TextAlign.Center
            )
        }
    }

}
