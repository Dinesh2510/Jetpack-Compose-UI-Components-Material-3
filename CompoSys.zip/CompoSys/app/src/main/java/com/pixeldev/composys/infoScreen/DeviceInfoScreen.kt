package com.pixeldev.composys.infoScreen

import androidx.compose.foundation.Image
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.ElevatedCard
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.remember
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.PlatformTextStyle
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.navigation.NavHostController
import com.pixeldev.composys.utlis.CommonToolbar
import com.pixeldev.composys.utlis.DeviceInfoProvider
import com.pixeldev.composys.R
import com.pixeldev.composys.utlis.CommonScaffold
import com.pixeldev.composys.utlis.Constant.formatBytes
import com.pixeldev.composys.utlis.Constant.getTotalRAM
import com.pixeldev.composys.utlis.Constant.getTotalStorage
import com.pixeldev.composys.utlis.TextsWithDivider

@Composable
fun DeviceInfoScreen(navController: NavHostController) {

    val context = LocalContext.current
    val info = remember { DeviceInfoProvider.getDeviceInfo(context) }
    CommonScaffold(
        title = "Device Info",
        onBackClick = { navController.popBackStack() }) { padding ->
        LazyColumn(
            modifier = Modifier
                .padding(padding)
                .fillMaxSize()
                .padding(16.dp)
        ) {
            item {
                ImageCard(
                    imageRes = R.drawable.android,  // Replace with your drawable resource
                    title = info.manufacturer,
                    subtitle = "• RAM: ${formatBytes(getTotalRAM(context))} • Storage: ${
                        formatBytes(
                            getTotalStorage()
                        )
                    }"
                )
            }

            item { TextsWithDivider("Brand", info.brand) }
            item { TextsWithDivider("Manufacturer", info.manufacturer) }
            item { TextsWithDivider("Model", info.model) }
            item { TextsWithDivider("Device", info.device) }
            item { TextsWithDivider("Product", info.product) }
            item { TextsWithDivider("Hardware", info.hardware) }
            item { TextsWithDivider("Board", info.board) }
            item { TextsWithDivider("User", info.user) }
            item { TextsWithDivider("Android Version", info.androidVersion) }
            item { TextsWithDivider("SDK", info.sdkInt.toString()) }
            item { TextsWithDivider("Android ID", info.androidId) }
            item { TextsWithDivider("Serial Number", info.serial) }
        }
    }
}

@Composable
fun InfoRow(label: String, value: String) {
    Column(modifier = Modifier.padding(vertical = 6.dp)) {
        Text(text = label, style = MaterialTheme.typography.labelMedium)
        Text(
            text = value,
            style = MaterialTheme.typography.bodyMedium,
            modifier = Modifier.padding(start = 8.dp)
        )
        HorizontalDivider(
            modifier = Modifier.padding(vertical = 4.dp)
        )
    }
}

@Composable
fun ImageCard(
    imageRes: Int,
    title: String,
    subtitle: String,
    modifier: Modifier = Modifier
) {
    ElevatedCard(
        modifier = modifier
            .fillMaxWidth()
            .padding(12.dp),
        shape = MaterialTheme.shapes.medium,
        elevation = CardDefaults.elevatedCardElevation(defaultElevation = 6.dp)
    ) {
        Row(
            modifier = Modifier
                .padding(16.dp)
                .fillMaxWidth(),
            verticalAlignment = Alignment.CenterVertically
        ) {
            // Image on the left
            Image(
                painter = painterResource(id = imageRes),
                contentDescription = null,
                modifier = Modifier
                    .size(64.dp)
                    .clip(RoundedCornerShape(8.dp)),
                contentScale = ContentScale.Crop
            )

            Spacer(modifier = Modifier.width(16.dp))

            // Title and Subtitle stacked vertically
            Column(
                modifier = Modifier.fillMaxWidth()
            ) {
                Text(
                    text = title,
                    fontSize = 20.sp,
                    maxLines = 1,
                    fontWeight = FontWeight.Bold,
                    overflow = TextOverflow.Ellipsis
                )
                Spacer(modifier = Modifier.height(4.dp))
                Text(
                    text = subtitle,
                    fontSize = 14.sp,
                    color = Color.Gray,
                    maxLines = 2,
                    /*style = TextStyle(
                        platformStyle = PlatformTextStyle(includeFontPadding = false)
                    )*/
                )
            }
        }
    }

}

