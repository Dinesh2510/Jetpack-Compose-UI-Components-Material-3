package com.pixeldev.composys.testingScreen
import android.Manifest
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.location.LocationManager
import android.net.wifi.ScanResult
import android.net.wifi.WifiManager
import android.os.Build
import android.provider.Settings
import android.util.Log
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.LocationOff
import androidx.compose.material.icons.filled.Refresh
import androidx.compose.material.icons.filled.Wifi
import androidx.compose.material.icons.filled.WifiOff
import androidx.compose.material3.Button
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.Divider
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.navigation.NavController
import com.pixeldev.composys.utlis.CommonScaffold
import kotlinx.coroutines.channels.Channel


/*
@Composable
fun WifiScannerScreen(navController: NavController) {
    CommonScaffold(title = "Wi‑Fi Scanner", onBackClick = { navController.popBackStack() }) { padding ->

        val context = LocalContext.current
        val wifiManager = remember {
            context.applicationContext.getSystemService(Context.WIFI_SERVICE) as WifiManager
        }

        var hasPermission by remember { mutableStateOf(false) }
        var scanResults by remember { mutableStateOf<List<WifiMeasureData>>(emptyList()) }
        var isScanning by remember { mutableStateOf(false) }
        var isWifiEnabled by remember { mutableStateOf(wifiManager.isWifiEnabled) }

        // Permissions for different Android versions
        val permissions = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
            arrayOf(Manifest.permission.NEARBY_WIFI_DEVICES)
        } else {
            arrayOf(Manifest.permission.ACCESS_FINE_LOCATION)
        }

        val permissionLauncher = rememberLauncherForActivityResult(
            contract = ActivityResultContracts.RequestMultiplePermissions()
        ) { result ->
            hasPermission = result.all { it.value }
        }

        // Request permission on first launch
        LaunchedEffect(Unit) {
            permissionLauncher.launch(permissions)
        }

        // Observe Wi-Fi state changes
        DisposableEffect(Unit) {
            val stateReceiver = object : BroadcastReceiver() {
                override fun onReceive(context: Context?, intent: Intent?) {
                    isWifiEnabled = wifiManager.isWifiEnabled
                }
            }
            val intentFilter = IntentFilter(WifiManager.WIFI_STATE_CHANGED_ACTION)
            context.registerReceiver(stateReceiver, intentFilter)

            onDispose {
                context.unregisterReceiver(stateReceiver)
            }
        }

        // Start scan when permission is granted and Wi-Fi is enabled
        DisposableEffect(hasPermission, isWifiEnabled) {
            if (!hasPermission || !isWifiEnabled) return@DisposableEffect onDispose {}

            val receiver = object : BroadcastReceiver() {
                override fun onReceive(ctx: Context?, intent: Intent?) {
                    scanResults = wifiManager.scanResults.map {
                        WifiMeasureData(it.BSSID ?: "?", it.level)
                    }
                    isScanning = false
                }
            }

            val filter = IntentFilter(WifiManager.SCAN_RESULTS_AVAILABLE_ACTION)
            context.registerReceiver(receiver, filter)

            isScanning = wifiManager.startScan()

            onDispose {
                context.unregisterReceiver(receiver)
            }
        }

        // UI
        Column(
            modifier = Modifier
                .padding(padding)
                .fillMaxSize()
                .padding(16.dp)
        ) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Icon(
                    imageVector = if (isWifiEnabled) Icons.Default.Wifi else Icons.Default.WifiOff,
                    contentDescription = "Wi-Fi State",
                    tint = if (isWifiEnabled) Color.Green else Color.Red,
                    modifier = Modifier.size(24.dp)
                )
                Spacer(Modifier.width(8.dp))
                Text(
                    text = if (isWifiEnabled) "Wi‑Fi is ON" else "Wi‑Fi is OFF",
                    color = if (isWifiEnabled) Color.Green else Color.Red,
                    fontWeight = FontWeight.Bold
                )
            }

            Spacer(Modifier.height(16.dp))

            Button(onClick = {
                if (hasPermission && isWifiEnabled) {
                    isScanning = wifiManager.startScan()
                }
            }) {
                Text("Refresh Wi‑Fi List")
            }

            Spacer(Modifier.height(16.dp))

            if (!hasPermission) {
                Text("Permissions not granted to scan Wi‑Fi.", color = Color.Red)
                return@Column
            }

            if (!isWifiEnabled) {
                Text("Turn on Wi‑Fi to scan networks.", color = Color.Red)
                return@Column
            }

            if (isScanning) {
                CircularProgressIndicator()
            } else if (scanResults.isEmpty()) {
                Text("No networks found.")
            } else {
                LazyColumn {
                    items(scanResults.size) { data ->
                        Text("BSSID: ${scanResults[data].bssid}, Signal: ${scanResults[data].signalStrength} dBm")
                        Divider()
                    }
                }
            }
        }
    }
}

*/

@Composable
fun WifiScannerScreen(navController: NavController) {
    CommonScaffold(title = "Wi‑Fi Scanner", onBackClick = { navController.popBackStack() }) { padding ->

        val context = LocalContext.current
        val wifiManager = remember {
            context.applicationContext.getSystemService(Context.WIFI_SERVICE) as WifiManager
        }

        var hasPermission by remember { mutableStateOf(false) }
        var scanResults by remember { mutableStateOf<List<ScanResult>>(emptyList()) }
        var isScanning by remember { mutableStateOf(false) }
        var isWifiEnabled by remember { mutableStateOf(wifiManager.isWifiEnabled) }
        var isLocationEnabled by remember { mutableStateOf(isLocationOn(context)) }

        val permissions = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
            arrayOf(Manifest.permission.NEARBY_WIFI_DEVICES)
        } else {
            arrayOf(Manifest.permission.ACCESS_FINE_LOCATION)
        }

        val permissionLauncher = rememberLauncherForActivityResult(
            contract = ActivityResultContracts.RequestMultiplePermissions()
        ) { result ->
            hasPermission = result.all { it.value }
        }

        // Request permission on launch
        LaunchedEffect(Unit) {
            permissionLauncher.launch(permissions)
        }

        // Watch location toggle
        DisposableEffect(Unit) {
            val receiver = object : BroadcastReceiver() {
                override fun onReceive(context: Context?, intent: Intent?) {
                    isLocationEnabled = isLocationOn(context!!)
                }
            }
            val filter = IntentFilter(LocationManager.PROVIDERS_CHANGED_ACTION)
            context.registerReceiver(receiver, filter)

            onDispose { context.unregisterReceiver(receiver) }
        }

        // Watch Wi‑Fi toggle
        DisposableEffect(Unit) {
            val receiver = object : BroadcastReceiver() {
                override fun onReceive(context: Context?, intent: Intent?) {
                    isWifiEnabled = wifiManager.isWifiEnabled
                }
            }
            val filter = IntentFilter(WifiManager.WIFI_STATE_CHANGED_ACTION)
            context.registerReceiver(receiver, filter)

            onDispose { context.unregisterReceiver(receiver) }
        }

        // Scan logic
        DisposableEffect(hasPermission, isWifiEnabled, isLocationEnabled) {
            if (!hasPermission || !isWifiEnabled || !isLocationEnabled) return@DisposableEffect onDispose {}

            val receiver = object : BroadcastReceiver() {
                override fun onReceive(context: Context?, intent: Intent?) {
                    scanResults = wifiManager.scanResults
                    isScanning = false
                }
            }

            context.registerReceiver(receiver, IntentFilter(WifiManager.SCAN_RESULTS_AVAILABLE_ACTION))
            isScanning = wifiManager.startScan()

            onDispose {
                context.unregisterReceiver(receiver)
            }
        }

        Column(
            modifier = Modifier
                .padding(padding)
                .fillMaxSize()
                .padding(16.dp)
        ) {

            // Wi‑Fi Status
            Row(verticalAlignment = Alignment.CenterVertically) {
                Icon(
                    if (isWifiEnabled) Icons.Default.Wifi else Icons.Default.WifiOff,
                    contentDescription = "Wi‑Fi State",
                    tint = if (isWifiEnabled) Color(0xFF4CAF50) else Color.Red,
                    modifier = Modifier.size(24.dp)
                )
                Spacer(Modifier.width(8.dp))
                Text(
                    if (isWifiEnabled) "Wi‑Fi is ON" else "Wi‑Fi is OFF",
                    color = if (isWifiEnabled) Color(0xFF4CAF50) else Color.Red,
                    fontWeight = FontWeight.Bold
                )
            }

            Spacer(Modifier.height(16.dp))

            if (!isLocationEnabled) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Icon(Icons.Default.LocationOff, contentDescription = null, tint = Color.Red)
                    Spacer(Modifier.width(8.dp))
                    Text("Location is OFF. Turn it ON to scan Wi‑Fi.", color = Color.Red)
                }
                Spacer(Modifier.height(8.dp))
                Button(onClick = {
                    context.startActivity(Intent(Settings.ACTION_LOCATION_SOURCE_SETTINGS))
                }) {
                    Text("Enable Location")
                }
                return@Column
            }

            if (!hasPermission) {
                Text("Wi‑Fi scan permission not granted.", color = Color.Red)
                return@Column
            }

            Spacer(Modifier.height(12.dp))

            Button(onClick = {
                if (hasPermission && isWifiEnabled && isLocationEnabled) {
                    isScanning = wifiManager.startScan()
                }
            }) {
                Icon(Icons.Default.Refresh, contentDescription = null)
                Spacer(modifier = Modifier.width(8.dp))
                Text("Refresh Wi‑Fi List")
            }

            Spacer(Modifier.height(12.dp))

            if (isScanning) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    CircularProgressIndicator(modifier = Modifier.size(20.dp))
                    Spacer(modifier = Modifier.width(8.dp))
                    Text("Scanning for Wi‑Fi networks...")
                }
            } else if (scanResults.isEmpty()) {
                Text("No Wi‑Fi networks found.", color = Color.Gray)
            } else {
                LazyColumn(modifier = Modifier.fillMaxSize()) {
                    items(scanResults.size) { data ->
                        Card (
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(vertical = 6.dp),
                            colors = CardDefaults.cardColors(containerColor = Color(0xFFF3F4F6)),
                            elevation = CardDefaults.cardElevation(defaultElevation = 4.dp)
                        ) {
                            Row(
                                modifier = Modifier
                                    .padding(16.dp)
                                    .fillMaxWidth(),
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Icon(
                                    imageVector = Icons.Default.Wifi,
                                    contentDescription = null,
                                    tint = getSignalColor(scanResults[data].level),
                                    modifier = Modifier.size(32.dp)
                                )
                                Spacer(modifier = Modifier.width(12.dp))
                                Column {
                                    Text(
                                        text = scanResults[data].SSID.ifBlank { "Unknown Network" },
                                        style = MaterialTheme.typography.titleMedium,
                                        fontWeight = FontWeight.SemiBold
                                    )
                                    Text(
                                        text = "BSSID: ${scanResults[data].BSSID}",
                                        style = MaterialTheme.typography.bodySmall,
                                        color = Color.Gray
                                    )
                                    Text(
                                        text = "Signal: ${scanResults[data].level} dBm ${getSignalEmoji(scanResults[data].level)}",
                                        style = MaterialTheme.typography.bodySmall
                                    )
                                }
                            }
                        }
                    }
                }
            }
        }
    }
}

// Util: Determine location status
fun isLocationOn(context: Context): Boolean {
    val locationManager = context.getSystemService(Context.LOCATION_SERVICE) as LocationManager
    return locationManager.isProviderEnabled(LocationManager.GPS_PROVIDER) ||
            locationManager.isProviderEnabled(LocationManager.NETWORK_PROVIDER)
}

// Util: Signal strength indicator
fun getSignalEmoji(level: Int): String {
    return when {
        level >= -50 -> "📶📶📶" // Excellent
        level >= -60 -> "📶📶"    // Good
        level >= -70 -> "📶"      // Fair
        else -> "❌"              // Weak
    }
}

// Util: Color based on signal strength
fun getSignalColor(level: Int): Color {
    return when {
        level >= -50 -> Color(0xFF4CAF50) // Green
        level >= -70 -> Color(0xFFFFC107) // Amber
        else -> Color(0xFFF44336)         // Red
    }
}
