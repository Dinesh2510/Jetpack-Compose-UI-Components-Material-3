package com.pixeldev.composys.testingScreen

import android.Manifest
import android.bluetooth.BluetoothAdapter
import android.bluetooth.BluetoothDevice
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.os.Build
import android.os.Handler
import android.os.Looper
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Bluetooth
import androidx.compose.material.icons.filled.Security
import androidx.compose.material3.Button
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.Divider
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.dp
import androidx.navigation.NavController
import com.pixeldev.composys.utlis.CommonScaffold
@Composable
fun BluetoothScreen(navController: NavController? = null) {
    val context = LocalContext.current
    val bluetoothAdapter = BluetoothAdapter.getDefaultAdapter()

    var isBluetoothEnabled by remember { mutableStateOf(bluetoothAdapter?.isEnabled == true) }
    var hasPermission by remember { mutableStateOf(false) }

    var pairedDevices by remember { mutableStateOf<List<BluetoothDevice>>(emptyList()) }
    var nearbyDevices by remember { mutableStateOf<Set<BluetoothDevice>>(emptySet()) }

    val permissionLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.RequestMultiplePermissions()
    ) { permissions ->
        hasPermission = permissions.values.all { it }
        if (hasPermission) {
            pairedDevices = getPairedBluetoothDevices(context)
            startDiscovery(bluetoothAdapter, context) { device ->
                nearbyDevices = nearbyDevices + device
            }
        }
    }

    // Permission request logic
    fun requestPermissions() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S) {
            permissionLauncher.launch(
                arrayOf(
                    Manifest.permission.BLUETOOTH_CONNECT,
                    Manifest.permission.BLUETOOTH_SCAN
                )
            )
        } else {
            permissionLauncher.launch(
                arrayOf(
                    Manifest.permission.ACCESS_FINE_LOCATION
                )
            )
        }
    }

    CommonScaffold(
        title = "Bluetooth Devices",
        onBackClick = { navController?.popBackStack() }
    ) { padding ->

        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(padding)
                .padding(16.dp),
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            when {
                !isBluetoothEnabled -> {
                    Button(onClick = {
                        val enableBtIntent = Intent(BluetoothAdapter.ACTION_REQUEST_ENABLE)
                        context.startActivity(enableBtIntent)
                        Handler(Looper.getMainLooper()).postDelayed({
                            isBluetoothEnabled = bluetoothAdapter?.isEnabled == true
                            if (isBluetoothEnabled) requestPermissions()
                        }, 1000)
                    }) {
                        Icon(Icons.Default.Bluetooth, contentDescription = null)
                        Spacer(modifier = Modifier.width(8.dp))
                        Text("Enable Bluetooth")
                    }
                }

                !hasPermission -> {
                    Button(onClick = { requestPermissions() }) {
                        Icon(Icons.Default.Security, contentDescription = null)
                        Spacer(modifier = Modifier.width(8.dp))
                        Text("Grant Permissions")
                    }
                }

                else -> {
                    Text(
                        "Paired Devices",
                        style = MaterialTheme.typography.headlineSmall,
                        modifier = Modifier.align(Alignment.Start)
                    )
                    Spacer(Modifier.height(12.dp))

                    if (pairedDevices.isEmpty()) {
                        Text("No paired devices found.")
                    } else {
                        DeviceList(devices = pairedDevices.toList())
                    }

                    Spacer(Modifier.height(24.dp))

                    Text(
                        "Nearby Devices",
                        style = MaterialTheme.typography.headlineSmall,
                        modifier = Modifier.align(Alignment.Start)
                    )
                    Spacer(Modifier.height(12.dp))

                    if (nearbyDevices.isEmpty()) {
                        Text("Scanning for nearby devices...")
                    } else {
                        DeviceList(devices = nearbyDevices.toList())
                    }
                }
            }
        }
    }
}

// Display Devices in a nice UI
@Composable
fun DeviceList(devices: List<BluetoothDevice>) {
    LazyColumn(modifier = Modifier.fillMaxWidth()) {
        items(devices.size) { device ->
            Card(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(vertical = 6.dp),
            ) {
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(16.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Icon(
                        imageVector = Icons.Default.Bluetooth,
                        contentDescription = null,
                        tint = MaterialTheme.colorScheme.primary,
                        modifier = Modifier.size(32.dp)
                    )
                    Spacer(modifier = Modifier.width(12.dp))
                    Column {
                        Text(
                            devices[device].name ?: "Unknown Device",
                            style = MaterialTheme.typography.titleMedium
                        )
                        Text(
                            devices[device].address,
                            style = MaterialTheme.typography.bodySmall,
                            color = Color.Gray
                        )
                    }
                }
            }
        }
    }
}

// Get paired devices


// Start device discovery
fun startDiscovery(
    adapter: BluetoothAdapter?,
    context: Context,
    onDeviceFound: (BluetoothDevice) -> Unit
) {
    if (adapter == null || adapter.isDiscovering) return

    val filter = IntentFilter(BluetoothDevice.ACTION_FOUND)
    val receiver = object : BroadcastReceiver() {
        override fun onReceive(ctx: Context, intent: Intent) {
            if (BluetoothDevice.ACTION_FOUND == intent.action) {
                val device: BluetoothDevice? =
                    intent.getParcelableExtra(BluetoothDevice.EXTRA_DEVICE)
                device?.let { onDeviceFound(it) }
            }
        }
    }

    context.registerReceiver(receiver, filter)
    adapter.startDiscovery()

    // Optional: stop discovery and unregister receiver after 15 seconds
    Handler(Looper.getMainLooper()).postDelayed({
        adapter.cancelDiscovery()
        try {
            context.unregisterReceiver(receiver)
        } catch (_: Exception) {}
    }, 15000)
}

fun getPairedBluetoothDevices(context: Context): List<BluetoothDevice> {
    val bluetoothAdapter = BluetoothAdapter.getDefaultAdapter()
    return if (bluetoothAdapter != null && bluetoothAdapter.isEnabled) {
        bluetoothAdapter.bondedDevices.toList()
    } else {
        emptyList()
    }
}


