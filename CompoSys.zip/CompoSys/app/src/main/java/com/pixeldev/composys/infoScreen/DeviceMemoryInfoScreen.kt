package com.pixeldev.composys.infoScreen

import android.os.Environment
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.material3.Scaffold
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.dp
import androidx.navigation.NavHostController
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.runtime.collectAsState
import androidx.compose.ui.Alignment
import androidx.lifecycle.viewmodel.compose.viewModel
import com.pixeldev.composys.utlis.Constant.getStorageInfo
import androidx.compose.runtime.getValue
import com.pixeldev.composys.utlis.CommonScaffold
import com.pixeldev.composys.utlis.CommonToolbar
import com.pixeldev.composys.utlis.MemoryUsageArc

@Composable
fun DeviceMemoryInfoScreen(
    navController: NavHostController,
    viewModel: DeviceInfoViewModel = viewModel()
) {
    val context = LocalContext.current
    val info = getDeviceOSInfo()
    val ramInfo by viewModel.ramInfo.collectAsState()
    val internalInfo by viewModel.internalStorage.collectAsState()
    val externalInfo by viewModel.externalStorage.collectAsState()

    CommonScaffold(
        title = "Memory Info",
        onBackClick = { navController.popBackStack() }) { padding ->
        LazyColumn(
            modifier = Modifier
                .padding(padding)
                .fillMaxSize()
                .padding(16.dp)
        ) {

            val internalStorage = getStorageInfo(Environment.getDataDirectory())
            val externalStorage =
                if (Environment.getExternalStorageState() == Environment.MEDIA_MOUNTED)
                    getStorageInfo(Environment.getExternalStorageDirectory()) else null

            item {
                Column(
                    modifier = Modifier
                        .fillMaxSize()
                        .padding(16.dp),
                    verticalArrangement = Arrangement.spacedBy(32.dp),
                    horizontalAlignment = Alignment.CenterHorizontally
                ) {
                    ramInfo?.let {
                        MemoryUsageArc(
                            label = "RAM Usage",
                            percent = it.usedPercent,
                            total = it.total,
                            used = it.used,
                            free = it.free
                        )
                    }

                    internalInfo?.let {
                        MemoryUsageArc(
                            label = "Internal Storage",
                            percent = it.usedPercent,
                            total = it.total,
                            used = it.used,
                            free = it.free
                        )
                    }

                    externalInfo?.let {
                        MemoryUsageArc(
                            label = "External Storage",
                            percent = it.usedPercent,
                            total = it.total,
                            used = it.used,
                            free = it.free
                        )
                    }
                }
            }
        }
    }
}


