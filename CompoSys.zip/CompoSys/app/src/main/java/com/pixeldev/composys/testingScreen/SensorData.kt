package com.pixeldev.composys.testingScreen

import android.app.Application
import android.content.Context
import android.hardware.*
import androidx.lifecycle.AndroidViewModel
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.asStateFlow

data class SensorData(
    val name: String,
    val values: List<Float> = listOf()
)

class SensorViewModel(app: Application) : AndroidViewModel(app), SensorEventListener {

    private val sensorManager = app.getSystemService(Context.SENSOR_SERVICE) as SensorManager
    private val _sensorReadings = MutableStateFlow<List<SensorData>>(emptyList())
    val sensorReadings = _sensorReadings.asStateFlow()

    private val sensors = mutableListOf<Pair<String, Sensor?>>()

    init {
        // Initialize sensors you want to track
        sensors.add("Accelerometer" to sensorManager.getDefaultSensor(Sensor.TYPE_ACCELEROMETER))
        sensors.add("Gyroscope" to sensorManager.getDefaultSensor(Sensor.TYPE_GYROSCOPE))
        sensors.add("Magnetometer" to sensorManager.getDefaultSensor(Sensor.TYPE_MAGNETIC_FIELD))
        sensors.add("Gravity" to sensorManager.getDefaultSensor(Sensor.TYPE_GRAVITY))
        sensors.add("Linear Acceleration" to sensorManager.getDefaultSensor(Sensor.TYPE_LINEAR_ACCELERATION))
        sensors.add("Rotation Vector" to sensorManager.getDefaultSensor(Sensor.TYPE_ROTATION_VECTOR))
        sensors.add("Proximity" to sensorManager.getDefaultSensor(Sensor.TYPE_PROXIMITY))
        sensors.add("Light" to sensorManager.getDefaultSensor(Sensor.TYPE_LIGHT))
        sensors.add("Pressure" to sensorManager.getDefaultSensor(Sensor.TYPE_PRESSURE))
        sensors.add("Step Counter" to sensorManager.getDefaultSensor(Sensor.TYPE_STEP_COUNTER))
        sensors.add("Step Detector" to sensorManager.getDefaultSensor(Sensor.TYPE_STEP_DETECTOR))
        sensors.add("Heart Rate" to sensorManager.getDefaultSensor(Sensor.TYPE_HEART_RATE))

        registerSensors()
    }

    private fun registerSensors() {
        for ((_, sensor) in sensors) {
            sensor?.let {
                sensorManager.registerListener(this, it, SensorManager.SENSOR_DELAY_UI)
            }
        }
    }

    override fun onSensorChanged(event: SensorEvent?) {
        event?.let {
            val name = when (event.sensor.type) {
                Sensor.TYPE_ACCELEROMETER -> "Accelerometer"
                Sensor.TYPE_GYROSCOPE -> "Gyroscope"
                Sensor.TYPE_MAGNETIC_FIELD -> "Magnetometer"
                Sensor.TYPE_GRAVITY -> "Gravity"
                Sensor.TYPE_LINEAR_ACCELERATION -> "Linear Acceleration"
                Sensor.TYPE_ROTATION_VECTOR -> "Rotation Vector"
                Sensor.TYPE_PROXIMITY -> "Proximity"
                Sensor.TYPE_LIGHT -> "Light"
                Sensor.TYPE_PRESSURE -> "Pressure"
                Sensor.TYPE_STEP_COUNTER -> "Step Counter"
                Sensor.TYPE_STEP_DETECTOR -> "Step Detector"
                Sensor.TYPE_HEART_RATE -> "Heart Rate"
                else -> "Unknown"
            }

            val updatedList = _sensorReadings.value.toMutableList()
            val index = updatedList.indexOfFirst { it.name == name }
            val newData = SensorData(name, event.values.toList())
            if (index >= 0) {
                updatedList[index] = newData
            } else {
                updatedList.add(newData)
            }
            _sensorReadings.value = updatedList
        }
    }

    override fun onAccuracyChanged(sensor: Sensor?, accuracy: Int) {}
    
    override fun onCleared() {
        super.onCleared()
        sensorManager.unregisterListener(this)
    }
}
