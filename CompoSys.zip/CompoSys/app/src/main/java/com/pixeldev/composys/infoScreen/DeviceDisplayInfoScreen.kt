package com.pixeldev.composys.infoScreen

import android.content.Context
import android.os.Build
import android.view.Display
import android.view.WindowManager
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.remember
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.navigation.NavHostController
import com.pixeldev.composys.utlis.CommonScaffold
import com.pixeldev.composys.utlis.getExtendedDisplayInfo
import com.pixeldev.composys.utlis.getFullDisplayInfo

@Composable
fun DeviceDisplayInfoScreen(navHostController: NavHostController) {
    CommonScaffold(
        title = "Display Info",
        onBackClick = { navHostController.popBackStack() }) { padding ->

        val context = LocalContext.current
        val info = remember { getFullDisplayInfo(context) }
        val infoExt = remember { getExtendedDisplayInfo(context) }

        LazyColumn(
            modifier = Modifier
                .fillMaxSize()
                .padding(padding)
                .padding(16.dp)
        ) {
            item {
                Text("Screen Info", style = MaterialTheme.typography.titleLarge)
                InfoCard("Screen Size", "${"%.2f".format(info.screenInches)} inches")
                InfoCard("Width", "${info.screenWidthPx}px")
                InfoCard("Height", "${info.screenHeightPx}px")
                InfoCard("Refresh Rate", "${info.refreshRate} Hz")
                InfoCard("Display Name", info.displayName ?: "N/A")
            }

            item {
                Spacer(Modifier.height(16.dp))
                Text("Density Info", style = MaterialTheme.typography.titleLarge)
                InfoCard("Density Bucket", info.densityBucket)
                InfoCard("Density DPI", "${info.densityDpi} dpi")
                InfoCard("Logical Density", info.density.toString())
                InfoCard("Scaled Density", info.scaledDensity.toString())
                InfoCard("xdpi / ydpi", "${info.xdpi} / ${info.ydpi}")
            }

            item {
                Spacer(Modifier.height(16.dp))
                Text("Resolution Info", style = MaterialTheme.typography.titleLarge)
                InfoCard("Usable Width x Height", "${info.screenWidthPx} x ${info.screenHeightPx}")
                InfoCard("Real Width x Height", "${info.realWidthPx} x ${info.realHeightPx}")
                InfoCard("Width (dp)", "${info.screenWidthDp} dp")
                InfoCard("Height (dp)", "${info.screenHeightDp} dp")
                InfoCard("Smallest Width (dp)", "${info.smallestWidthDp} dp")
            }

            item {
                Spacer(Modifier.height(16.dp))
                Text("Device Capabilities", style = MaterialTheme.typography.titleLarge)
                InfoCard("Orientation", infoExt.orientation)
                InfoCard("Layout Size", infoExt.layoutSize)
                InfoCard("Wide Color Gamut", if (infoExt.isWideColorGamut) "Yes" else "No")
                InfoCard("Display Secure", infoExt.isDisplaySecure.toString())
                InfoCard("Display Cutout", if (infoExt.hasDisplayCutout) "Present" else "None")
            }

            item {
                Spacer(Modifier.height(16.dp))
                Text("Advanced Display Features", style = MaterialTheme.typography.titleLarge)
                InfoCard("Physical Width (in)", "%.2f".format(infoExt.physicalSizeInches.first))
                InfoCard("Physical Height (in)", "%.2f".format(infoExt.physicalSizeInches.second))
                InfoCard(
                    "HDR Support",
                    if (infoExt.hdrTypes.isEmpty()) "None" else infoExt.hdrTypes.joinToString()
                )
            }

            item {
                DisplayFlagsInfo()
            }
        }
    }
}

@Composable
fun DisplayFlagsInfo() {
    val context = LocalContext.current

    val flags = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.R) {
        context.display?.flags ?: 0
    } else {
        @Suppress("DEPRECATION")
        (context.getSystemService(Context.WINDOW_SERVICE) as WindowManager).defaultDisplay.flags
    }

    val isSecure = (flags and Display.FLAG_SECURE) != 0
    val supportsProtectedBuffers = (flags and Display.FLAG_SUPPORTS_PROTECTED_BUFFERS) != 0
    val isPrivate = (flags and Display.FLAG_PRIVATE) != 0
    val isRound = (flags and Display.FLAG_ROUND) != 0

    Column(modifier = Modifier.padding(0.dp)) {
        Text("Display Flags", style = MaterialTheme.typography.titleLarge)

        InfoCard("FLAG_SECURE", isSecure.toString())
        InfoCard("FLAG_SUPPORTS_PROTECTED_BUFFERS", supportsProtectedBuffers.toString())
        InfoCard("FLAG_PRIVATE", isPrivate.toString())
        InfoCard("FLAG_ROUND", isRound.toString())
    }
}

@Composable
fun InfoCard(title: String, value: String) {
    Card(Modifier
        .fillMaxWidth()
        .padding(vertical = 4.dp),
        colors = CardDefaults.cardColors(containerColor = Color(0xffF8A44C).copy(alpha = 0.1f)),
        border = BorderStroke(2.dp, Color(0xffF8A44C).copy(alpha = 0.7f)),
        shape = RoundedCornerShape(12.dp),
        elevation = CardDefaults.cardElevation(defaultElevation = 0.dp)
    ) {
        Column(Modifier.padding(12.dp)) {
            Text(title,  fontWeight = FontWeight.Medium,)
            Text(value,  fontWeight = FontWeight.Normal,)
        }
    }
}
