package com.pixeldev.composys.utlis

data class DeviceInfoModel(
    val brand: String,
    val manufacturer: String,
    val model: String,
    val device: String,
    val product: String,
    val hardware: String,
    val board: String,
    val serial: String,
    val user: String,
    val androidVersion: String,
    val sdkInt: Int,
    val androidId: String
)
