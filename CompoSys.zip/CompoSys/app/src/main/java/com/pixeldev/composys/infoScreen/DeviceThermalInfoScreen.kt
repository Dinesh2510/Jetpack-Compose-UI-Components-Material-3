package com.pixeldev.composys.infoScreen

import android.os.PowerManager
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.material3.Card
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp

import android.os.Build
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.layout.*
import androidx.compose.material3.*
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.runtime.*
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.navigation.NavHostController
import com.pixeldev.composys.utlis.CommonScaffold
import com.pixeldev.composys.utlis.Constant.getAnyTemperature
import com.pixeldev.composys.utlis.Constant.getThermalHeadroom
import com.pixeldev.composys.utlis.Constant.getThermalHeadroomThresholds
import com.pixeldev.composys.utlis.Constant.getThermalStatus

@Composable
fun DeviceThermalInfoScreen(navController: NavHostController) {
    val context = LocalContext.current
    var thermalStatus by remember { mutableStateOf(0) }
    var cpuTemp by remember { mutableStateOf<Float?>(null) }
    var headroom by remember { mutableStateOf<Float?>(null) }
    var thresholds by remember { mutableStateOf<Map<Int, Float>>(emptyMap()) }

    LaunchedEffect(true) {
        thermalStatus = getThermalStatus(context)

        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.N) {
            cpuTemp = getAnyTemperature(context)
        }

        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.R) {
            headroom = getThermalHeadroom(context)
            thresholds = getThermalHeadroomThresholds(context)
        }
    }

    CommonScaffold(
        title = "Thermal Info",
        onBackClick = { navController.popBackStack() }) {

    Column(
        modifier = Modifier
            .fillMaxSize().padding(it)
            .padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp)
    ) {

        ThermalStatusCard(thermalStatus)
        TemperatureCard(cpuTemp)

        if (headroom != null) {
            ThermalHeadroomCard(headroom!!)
        }

        if (thresholds.isNotEmpty()) {
            ThermalThresholdsCard(thresholds)
        }
    }}
}

@Composable
fun ThermalThresholdsCard(thresholds: Map<Int, Float>) {
    if (thresholds.isEmpty()) return

    Card(
        modifier = Modifier.fillMaxWidth(),
        border = BorderStroke(2.dp, Color(0xffB7DFF5)),
        elevation = CardDefaults.cardElevation(4.dp),
        colors = CardDefaults.cardColors(
            containerColor = Color(0xFFFFFFFF)
        )
    ) {
        Column(Modifier.padding(16.dp)) {
            Text("Thermal Thresholds", style = MaterialTheme.typography.titleMedium)

            thresholds.forEach { (status, threshold) ->
                val statusLabel = when (status) {
                    PowerManager.THERMAL_STATUS_NONE -> "Normal"
                    PowerManager.THERMAL_STATUS_LIGHT -> "Light"
                    PowerManager.THERMAL_STATUS_MODERATE -> "Moderate"
                    PowerManager.THERMAL_STATUS_SEVERE -> "Severe"
                    PowerManager.THERMAL_STATUS_CRITICAL -> "Critical"
                    PowerManager.THERMAL_STATUS_EMERGENCY -> "Emergency"
                    PowerManager.THERMAL_STATUS_SHUTDOWN -> "Shutdown"
                    else -> "Unknown ($status)"
                }
                Text("$statusLabel: Threshold = $threshold")
            }
        }
    }
}

@Composable
fun ThermalStatusCard(thermalStatus: Int) {
    val statusText = when (thermalStatus) {
        PowerManager.THERMAL_STATUS_NONE -> "Normal"
        PowerManager.THERMAL_STATUS_LIGHT -> "Light Throttling"
        PowerManager.THERMAL_STATUS_MODERATE -> "Moderate Throttling"
        PowerManager.THERMAL_STATUS_SEVERE -> "Severe Throttling"
        PowerManager.THERMAL_STATUS_CRITICAL -> "Critical"
        PowerManager.THERMAL_STATUS_EMERGENCY -> "Emergency"
        PowerManager.THERMAL_STATUS_SHUTDOWN -> "Shutting Down"
        else -> "Unknown"
    }

    Card(
        modifier = Modifier.fillMaxWidth(),
        border = BorderStroke(2.dp, Color(0xffB7DFF5)),
        elevation = CardDefaults.cardElevation(4.dp),
        colors = CardDefaults.cardColors(
            containerColor = Color(0xFFFFFFFF)
        )) {
        Column(Modifier.padding(16.dp)) {
            Text("Thermal Status", style = MaterialTheme.typography.titleMedium)
            Text(statusText, style = MaterialTheme.typography.bodyLarge)
        }
    }
}

@Composable
fun TemperatureCard(cpuTemp: Float?) {
    Card(
        modifier = Modifier.fillMaxWidth(),
        border = BorderStroke(2.dp, Color(0xffB7DFF5)),
        elevation = CardDefaults.cardElevation(4.dp),
        colors = CardDefaults.cardColors(
            containerColor = Color(0xFFFFFFFF)
        )) {
        Column(Modifier.padding(16.dp)) {
            Text("CPU Temperature", style = MaterialTheme.typography.titleMedium)
            Text("${cpuTemp?.toString() ?: "N/A"} °C", style = MaterialTheme.typography.bodyLarge)
        }
    }
}

@Composable
fun ThermalHeadroomCard(headroom: Float) {
    Card(
        modifier = Modifier.fillMaxWidth(),
        border = BorderStroke(2.dp, Color(0xffB7DFF5)),
        elevation = CardDefaults.cardElevation(4.dp),
        colors = CardDefaults.cardColors(
            containerColor = Color(0xFFFFFFFF)
        )) {
        Column(Modifier.padding(16.dp)) {
            Text("Thermal Headroom", style = MaterialTheme.typography.titleMedium)
            LinearProgressIndicator(
            progress = { headroom },
            modifier = Modifier.fillMaxWidth(),
            color = MaterialTheme.colorScheme.primary,
            trackColor = MaterialTheme.colorScheme.surfaceVariant,
            strokeCap = ProgressIndicatorDefaults.LinearStrokeCap,
            )
            Text("${(headroom * 100).toInt()}%", style = MaterialTheme.typography.bodyLarge)
        }
    }
}
