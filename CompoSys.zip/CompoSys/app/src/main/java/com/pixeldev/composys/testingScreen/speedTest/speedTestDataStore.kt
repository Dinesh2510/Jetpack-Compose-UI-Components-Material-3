package com.pixeldev.composys.testingScreen.speedTest

import android.content.Context
import androidx.datastore.core.DataStore
import androidx.datastore.preferences.core.*
import androidx.datastore.preferences.preferencesDataStore
import com.google.gson.Gson
import com.google.gson.reflect.TypeToken
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.map
import androidx.datastore.preferences.core.stringPreferencesKey

val Context.speedTestDataStore: DataStore<Preferences> by preferencesDataStore(name = "speed_test")

class SpeedTestDataStore(private val context: Context) {
    private val gson = Gson()
    private val KEY_RESULTS = stringPreferencesKey("results")

    val resultsFlow: Flow<List<SpeedTestResult>> = context.speedTestDataStore.data.map { prefs ->
        prefs[KEY_RESULTS]?.let {
            gson.fromJson(it, object : TypeToken<List<SpeedTestResult>>() {}.type)
        } ?: emptyList()
    }


    suspend fun saveResult(result: SpeedTestResult) {
        context.speedTestDataStore.edit { prefs ->
            val currentJson = prefs[KEY_RESULTS]
            val current: List<SpeedTestResult> = currentJson?.let {
                gson.fromJson(it, object : TypeToken<List<SpeedTestResult>>() {}.type)
            } ?: emptyList()

            val updated = listOf(result) + current
            prefs[KEY_RESULTS] = gson.toJson(updated)
        }
    }
}
