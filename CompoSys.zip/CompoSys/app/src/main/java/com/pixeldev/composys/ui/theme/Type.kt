package com.pixeldev.composys.ui.theme

import androidx.compose.material3.Typography
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.Font
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.sp

import com.pixeldev.composys.R

val Poppins = FontFamily(
    Font(R.font.poppins_medium, FontWeight.Medium),
    Font(R.font.poppins_regular, FontWeight.Normal),
    Font(R.font.poppins_semibold, FontWeight.Bold)
)

// Default Material 3 typography values
val baseline = Typography()

val AppTypography = Typography(
    displayLarge = baseline.displayLarge.copy(fontFamily = Poppins),
    displayMedium = baseline.displayMedium.copy(fontFamily = Poppins),
    displaySmall = baseline.displaySmall.copy(fontFamily = Poppins),
    headlineLarge = baseline.headlineLarge.copy(fontFamily = Poppins),
    headlineMedium = baseline.headlineMedium.copy(fontFamily = Poppins),
    headlineSmall = baseline.headlineSmall.copy(fontFamily = Poppins),
    titleLarge = baseline.titleLarge.copy(fontFamily = Poppins),
    titleMedium = baseline.titleMedium.copy(fontFamily = Poppins),
    titleSmall = baseline.titleSmall.copy(fontFamily = Poppins),
    bodyLarge = baseline.bodyLarge.copy(fontFamily = Poppins),
    bodyMedium = baseline.bodyMedium.copy(fontFamily = Poppins),
    bodySmall = baseline.bodySmall.copy(fontFamily = Poppins),
    labelLarge = baseline.labelLarge.copy(fontFamily = Poppins),
    labelMedium = baseline.labelMedium.copy(fontFamily = Poppins),
    labelSmall = baseline.labelSmall.copy(fontFamily = Poppins),
)

