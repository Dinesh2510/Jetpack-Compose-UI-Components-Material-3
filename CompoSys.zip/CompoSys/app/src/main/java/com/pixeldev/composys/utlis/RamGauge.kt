package com.pixeldev.composys.utlis

import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.tween
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.ui.Modifier
// Compose core
import androidx.compose.runtime.*
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.platform.LocalContext
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.layout.*
import androidx.compose.ui.unit.dp
import androidx.compose.runtime.setValue

// Android RAM info
import android.app.ActivityManager
import android.content.Context
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.material3.Text
import androidx.compose.ui.Alignment
import androidx.compose.ui.graphics.nativeCanvas

// For delay in LaunchedEffect
import kotlinx.coroutines.delay
import kotlin.math.ceil

// Math functions
import kotlin.math.cos
import kotlin.math.sin

@Composable
fun RamGauge(
    modifier: Modifier = Modifier,
    currentRamGB: Float,
    maxRamGB: Float = 16f
) {
    val sweepAngle = 180f
    val startAngle = 180f
    val divisions = maxRamGB.toInt()
    val labelInterval = 2 // Change this to 4, 8, etc. for other steps

    val animatedRam by animateFloatAsState(
        targetValue = currentRamGB,
        animationSpec = tween(durationMillis = 500),
        label = "ramAnimation"
    )

    Canvas(modifier = modifier.fillMaxSize()) {
        val centerX = size.width / 2f
        val centerY = size.height * 1f // 😵 This pushes the gauge very low ; previous =0.08f
        val radius = size.width * 0.4f
        val strokeWidth = radius * 0.15f
        val markerLength = strokeWidth * 0.5f

        // Draw gauge background arc
        drawArc(
            color = Color(0xff53b175).copy(alpha = 0.7f),
            startAngle = startAngle,
            sweepAngle = sweepAngle,
            useCenter = false,
            topLeft = Offset(centerX - radius, centerY - radius),
            size = Size(radius * 2, radius * 2),
            style = Stroke(width = strokeWidth, cap = StrokeCap.Round)
        )

        // Draw GB markers and labels
        for (i in 0..divisions) {
            val angleDeg = startAngle + (i * sweepAngle / divisions)
            val angleRad = Math.toRadians(angleDeg.toDouble()).toFloat()

            // Tick mark (draws at every GB)
            val lineStart = Offset(
                centerX + cos(angleRad) * (radius - markerLength),
                centerY + sin(angleRad) * (radius - markerLength)
            )
            val lineEnd = Offset(
                centerX + cos(angleRad) * (radius + markerLength),
                centerY + sin(angleRad) * (radius + markerLength)
            )
            drawLine(
                color = Color.DarkGray,
                start = lineStart,
                end = lineEnd,
                strokeWidth = 2f
            )

            // Only label every N GB (e.g., 2, 4, 6)
            if (i % labelInterval == 0) {
                val label = "$i"
                val textOffset = Offset(
                    centerX + cos(angleRad) * (radius + markerLength * 2f),
                    centerY + sin(angleRad) * (radius + markerLength * 2f)
                )

                drawContext.canvas.nativeCanvas.apply {
                    val paint = android.graphics.Paint().apply {
                        color = android.graphics.Color.DKGRAY
                        textSize = radius * 0.1f
                        textAlign = android.graphics.Paint.Align.CENTER
                        isAntiAlias = true
                    }

                    drawText(
                        label,
                        textOffset.x,
                        textOffset.y + (paint.textSize / 3),
                        paint
                    )
                }
            }
        }

        // Draw pointer (needle)
        val anglePerGb = sweepAngle / maxRamGB
        val pointerAngle = startAngle + (animatedRam * anglePerGb)
        val angleRad = Math.toRadians(pointerAngle.toDouble()).toFloat()
        val needleLength = radius * 0.9f

        drawLine(
            color = Color(0xFFF44336).copy(alpha = 0.7f),
            start = Offset(centerX, centerY),
            end = Offset(
                centerX + cos(angleRad) * needleLength,
                centerY + sin(angleRad) * needleLength
            ),
            strokeWidth = strokeWidth * 0.3f,
            cap = StrokeCap.Round
        )

        // Draw center knob
        drawCircle(
            color = Color.Black,
            center = Offset(centerX, centerY),
            radius = strokeWidth * 0.5f
        )
    }
}

@Composable
fun RamUsageSpeedometer(modifier: Modifier = Modifier, maxRamGB: Float = 16f) {
    var usedRamGB by remember { mutableStateOf(0f) }
    var totalRamGB by remember { mutableStateOf(16f) } // default to 16 GB
    val context = LocalContext.current

    LaunchedEffect(Unit) {
        val activityManager = context.getSystemService(Context.ACTIVITY_SERVICE) as ActivityManager

        // Get total RAM once
        val memInfoInit = ActivityManager.MemoryInfo()
        activityManager.getMemoryInfo(memInfoInit)
        totalRamGB = memInfoInit.totalMem / (1024 * 1024 * 1024f)

        // Update used RAM repeatedly
        while (true) {
            val memInfo = ActivityManager.MemoryInfo()
            activityManager.getMemoryInfo(memInfo)
            val usedMB = (memInfo.totalMem - memInfo.availMem) / (1024f * 1024f)
            usedRamGB = usedMB / 1024f
            delay(1000L)
        }
    }

   // val displayMaxRam = ceil(totalRamGB)//actual ram of phone in meter
    val displayMaxRam = ceil(maxRamGB)//16GB
    val roundedTotalRamGB = ceil(totalRamGB)

    Box(
        modifier = Modifier
            .fillMaxWidth().padding(horizontal = 8.dp)
            .heightIn(max = 200.dp), // optional hard cap
        contentAlignment = Alignment.Center
    ) {
        RamGauge(
            modifier = modifier,
            currentRamGB = usedRamGB.coerceAtMost(totalRamGB),
            maxRamGB = displayMaxRam
        )
        Column(horizontalAlignment = Alignment.CenterHorizontally) {
            Spacer(modifier = Modifier.height(8.dp))
            Text(
                text = "RAM Usage",
                color = Color(0xFF090100)
            )
            Text(
                text = String.format("%.1f GB / %.2f GB", usedRamGB, roundedTotalRamGB),
                color = Color(0xFF090100)
            )
        }
    }
}

@Composable
fun DualGaugeDashboard(
    ram1: Float,
    ram2: Float,
    maxRam: Float = 16f
) {
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .height(150.dp), // shared height
        horizontalArrangement = Arrangement.SpaceEvenly
    ) {
        RamGauge(
            modifier = Modifier
                .weight(1f)
                .padding(end = 8.dp), // spacing between gauges
            currentRamGB = ram1,
            maxRamGB = maxRam
        )

        RamGauge(
            modifier = Modifier
                .weight(1f)
                .padding(start = 8.dp),
            currentRamGB = ram2,
            maxRamGB = maxRam
        )
    }
}

/*🧪 Example

If maxRamGB = 16 and labelInterval = 2, you'll get:

Markers:   0 1 2 3 4 5 6 7 8 9 10 11 12 13 14 15 16
Labels:    0   2   4   6   8   10  12  14  16

Want to try 4 GB spacing? Just set:
val labelInterval = 4


*/

/*@Composable
fun RamUsageSpeedometer(modifier: Modifier = Modifier, maxRamGB: Float = 16f) {
    var usedRamGB by remember { mutableStateOf(0f) }
    var totalRamMB: Long = 0L
    var availRamMB: Long = 0L
    var usedRamGBReal by remember { mutableStateOf(0f) }
    val context = LocalContext.current

    LaunchedEffect(Unit) {
        val activityManager = context.getSystemService(Context.ACTIVITY_SERVICE) as ActivityManager
        while (true) {
            val memInfo = ActivityManager.MemoryInfo()
            activityManager.getMemoryInfo(memInfo)
             totalRamMB = memInfo.totalMem / (1024 * 1024)
             availRamMB = memInfo.availMem / (1024 * 1024)
             usedRamGBReal = (totalRamMB - availRamMB) / 1024f

            val usedMB = (memInfo.totalMem - memInfo.availMem) / (1024 * 1024)
            usedRamGB = usedMB / 1024f
            delay(1000L)
        }
    }*/