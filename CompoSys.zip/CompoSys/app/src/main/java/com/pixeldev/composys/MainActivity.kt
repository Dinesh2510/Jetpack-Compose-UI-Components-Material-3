package com.pixeldev.composys

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.animation.AnimatedContentTransitionScope
import androidx.compose.animation.core.FastOutSlowInEasing
import androidx.compose.animation.core.tween
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.navigation.compose.NavHost
import androidx.navigation.compose.composable
import androidx.navigation.compose.rememberNavController
import com.pixeldev.composys.infoScreen.BatteryInfoScreen
import com.pixeldev.composys.infoScreen.DeviceDisplayInfoScreen
import com.pixeldev.composys.infoScreen.DeviceFeaturesScreen
import com.pixeldev.composys.infoScreen.DeviceInfoScreen
import com.pixeldev.composys.infoScreen.DeviceMemoryInfoScreen
import com.pixeldev.composys.infoScreen.DeviceOSInfoScreen
import com.pixeldev.composys.infoScreen.DeviceProccerScreen
import com.pixeldev.composys.infoScreen.DeviceSensorInfoScreen
import com.pixeldev.composys.infoScreen.DeviceThermalInfoScreen
import com.pixeldev.composys.infoScreen.SimInfoScreen
import com.pixeldev.composys.infoScreen.SplashScreen
import com.pixeldev.composys.infoScreen.SystemAppLoaderScreen
import com.pixeldev.composys.testingScreen.BiometricAuthentication
import com.pixeldev.composys.testingScreen.BluetoothScreen
import com.pixeldev.composys.testingScreen.DisplayTestScreen
import com.pixeldev.composys.testingScreen.FlashlightTestScreen
import com.pixeldev.composys.testingScreen.LightSensorScreen
import com.pixeldev.composys.testingScreen.MicrophoneTestScreen
import com.pixeldev.composys.testingScreen.ProximityScreen
import com.pixeldev.composys.testingScreen.SensorTestScreen
import com.pixeldev.composys.testingScreen.TouchTestScreen
import com.pixeldev.composys.testingScreen.VibrationTestScreen
import com.pixeldev.composys.testingScreen.VolumeScreen
import com.pixeldev.composys.testingScreen.WifiScannerScreen
import com.pixeldev.composys.testingScreen.speedTest.HistoryScreen
import com.pixeldev.composys.testingScreen.speedTest.MySpeedTestScreen
import com.pixeldev.composys.ui.theme.CompoSysTheme
import dagger.hilt.android.AndroidEntryPoint

@AndroidEntryPoint
class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        setContent {
            CompoSysTheme {
            val navController = rememberNavController()
            NavHost(navController = navController, startDestination = Screen.Splash.route) {
                composable(
                    Screen.Splash.route,
                    enterTransition = {
                        slideIntoContainer(
                            AnimatedContentTransitionScope.SlideDirection.End,
                            tween(500)
                        ) + fadeIn(tween(300))
                    },
                    exitTransition = { fadeOut(tween(400)) }
                ) {
                    SplashScreen(navController)
                }
                composable(
                    Screen.Onboarding.route,
                    enterTransition = {
                        slideIntoContainer(
                            AnimatedContentTransitionScope.SlideDirection.Right,
                            animationSpec = tween(
                                durationMillis = 400,
                                easing = FastOutSlowInEasing
                            )
                        )
                    },
                    exitTransition = {
                        slideOutOfContainer(
                            AnimatedContentTransitionScope.SlideDirection.Left,
                            animationSpec = tween(
                                durationMillis = 400,
                                easing = FastOutSlowInEasing
                            )
                        )
                    }
                ) {
                    OnboardingScreen(navController)
                }
                composable(
                    Screen.Main.route,
                    enterTransition = {
                        slideIntoContainer(
                            AnimatedContentTransitionScope.SlideDirection.Right,
                            animationSpec = tween(500)
                        )
                    },
                    exitTransition = {
                        slideOutOfContainer(
                            AnimatedContentTransitionScope.SlideDirection.Left,
                            animationSpec = tween(500)
                        )
                    }
                ) {
                    MainInfoScreen(navController)
                }
                composable(
                    Screen.DeviceInfo.route,
                    enterTransition = {
                        slideIntoContainer(
                            AnimatedContentTransitionScope.SlideDirection.Right,
                            animationSpec = tween(500)
                        )
                    },
                    exitTransition = {
                        slideOutOfContainer(
                            AnimatedContentTransitionScope.SlideDirection.Left,
                            animationSpec = tween(500)
                        )
                    }
                ) {
                    DeviceInfoScreen(navController)
                }
                composable(
                    Screen.DeviceOSInfo.route,
                    enterTransition = {
                        slideIntoContainer(
                            AnimatedContentTransitionScope.SlideDirection.Right,
                            animationSpec = tween(500)
                        )
                    },
                    exitTransition = {
                        slideOutOfContainer(
                            AnimatedContentTransitionScope.SlideDirection.Left,
                            animationSpec = tween(500)
                        )
                    }
                ) {
                    DeviceOSInfoScreen(navController)
                }
                composable(
                    Screen.DeviceMemoryInfo.route,
                    enterTransition = {
                        slideIntoContainer(
                            AnimatedContentTransitionScope.SlideDirection.Right,
                            animationSpec = tween(500)
                        )
                    },
                    exitTransition = {
                        slideOutOfContainer(
                            AnimatedContentTransitionScope.SlideDirection.Left,
                            animationSpec = tween(500)
                        )
                    }
                ) {
                    DeviceMemoryInfoScreen(navController)
                }
                 composable(
                    Screen.DeviceBatteryInfo.route,
                    enterTransition = {
                        slideIntoContainer(
                            AnimatedContentTransitionScope.SlideDirection.Right,
                            animationSpec = tween(500)
                        )
                    },
                    exitTransition = {
                        slideOutOfContainer(
                            AnimatedContentTransitionScope.SlideDirection.Left,
                            animationSpec = tween(500)
                        )
                    }
                ) {
                     BatteryInfoScreen(navController)
                }
                composable(
                    Screen.DeviceThermalInfo.route,
                    enterTransition = {
                        slideIntoContainer(
                            AnimatedContentTransitionScope.SlideDirection.Right,
                            animationSpec = tween(500)
                        )
                    },
                    exitTransition = {
                        slideOutOfContainer(
                            AnimatedContentTransitionScope.SlideDirection.Left,
                            animationSpec = tween(500)
                        )
                    }
                ) {
                    DeviceThermalInfoScreen(navController)
                }
                composable(
                    Screen.DeviceSimInfo.route,
                    enterTransition = {
                        slideIntoContainer(
                            AnimatedContentTransitionScope.SlideDirection.Right,
                            animationSpec = tween(500)
                        )
                    },
                    exitTransition = {
                        slideOutOfContainer(
                            AnimatedContentTransitionScope.SlideDirection.Left,
                            animationSpec = tween(500)
                        )
                    }
                ) {
                    SimInfoScreen(navController)
                }
                composable(
                    Screen.DeviceDisplayInfo.route,
                    enterTransition = {
                        slideIntoContainer(
                            AnimatedContentTransitionScope.SlideDirection.Right,
                            animationSpec = tween(500)
                        )
                    },
                    exitTransition = {
                        slideOutOfContainer(
                            AnimatedContentTransitionScope.SlideDirection.Left,
                            animationSpec = tween(500)
                        )
                    }
                ) {
                    DeviceDisplayInfoScreen(navController)
                }
                composable(
                    Screen.DeviceSensorInfo.route,
                    enterTransition = {
                        slideIntoContainer(
                            AnimatedContentTransitionScope.SlideDirection.Right,
                            animationSpec = tween(500)
                        )
                    },
                    exitTransition = {
                        slideOutOfContainer(
                            AnimatedContentTransitionScope.SlideDirection.Left,
                            animationSpec = tween(500)
                        )
                    }
                ) {
                    DeviceSensorInfoScreen(navController)
                }

                composable(
                    Screen.DeviceProccerInfo.route,
                    enterTransition = {
                        slideIntoContainer(
                            AnimatedContentTransitionScope.SlideDirection.Right,
                            animationSpec = tween(500)
                        )
                    },
                    exitTransition = {
                        slideOutOfContainer(
                            AnimatedContentTransitionScope.SlideDirection.Left,
                            animationSpec = tween(500)
                        )
                    }
                ) {
                    DeviceProccerScreen(navController)
                }
                composable(
                    Screen.DeviceFeaturesInfo.route,
                    enterTransition = {
                        slideIntoContainer(
                            AnimatedContentTransitionScope.SlideDirection.Right,
                            animationSpec = tween(500)
                        )
                    },
                    exitTransition = {
                        slideOutOfContainer(
                            AnimatedContentTransitionScope.SlideDirection.Left,
                            animationSpec = tween(500)
                        )
                    }
                ) {
                    DeviceFeaturesScreen(navController)
                }
                composable(
                    Screen.MainTestScreen.route,
                    enterTransition = {
                        slideIntoContainer(
                            AnimatedContentTransitionScope.SlideDirection.Right,
                            animationSpec = tween(500)
                        )
                    },
                    exitTransition = {
                        slideOutOfContainer(
                            AnimatedContentTransitionScope.SlideDirection.Left,
                            animationSpec = tween(500)
                        )
                    }
                ) {
                    MainTestScreen(navController)
                }

                composable(
                    Screen.DisplayTest.route,
                    enterTransition = {
                        slideIntoContainer(
                            AnimatedContentTransitionScope.SlideDirection.Right,
                            animationSpec = tween(500)
                        )
                    },
                    exitTransition = {
                        slideOutOfContainer(
                            AnimatedContentTransitionScope.SlideDirection.Left,
                            animationSpec = tween(500)
                        )
                    }
                ) {
                    DisplayTestScreen(navController)
                }
                composable(
                    Screen.FlashLightTest.route,
                    enterTransition = {
                        slideIntoContainer(
                            AnimatedContentTransitionScope.SlideDirection.Right,
                            animationSpec = tween(500)
                        )
                    },
                    exitTransition = {
                        slideOutOfContainer(
                            AnimatedContentTransitionScope.SlideDirection.Left,
                            animationSpec = tween(500)
                        )
                    }
                ) {
                    FlashlightTestScreen(navController)
                }


                composable(
                    Screen.Volume.route,
                    enterTransition = {
                        slideIntoContainer(
                            AnimatedContentTransitionScope.SlideDirection.Right,
                            animationSpec = tween(500)
                        )
                    },
                    exitTransition = {
                        slideOutOfContainer(
                            AnimatedContentTransitionScope.SlideDirection.Left,
                            animationSpec = tween(500)
                        )
                    }
                ) {
                    VolumeScreen(navController)
                }

                composable(
                    Screen.WifiScanner.route,
                    enterTransition = {
                        slideIntoContainer(
                            AnimatedContentTransitionScope.SlideDirection.Right,
                            animationSpec = tween(500)
                        )
                    },
                    exitTransition = {
                        slideOutOfContainer(
                            AnimatedContentTransitionScope.SlideDirection.Left,
                            animationSpec = tween(500)
                        )
                    }
                ) {
                    WifiScannerScreen(navController)
                }

                composable(
                    Screen.TouchTest.route,
                    enterTransition = {
                        slideIntoContainer(
                            AnimatedContentTransitionScope.SlideDirection.Right,
                            animationSpec = tween(500)
                        )
                    },
                    exitTransition = {
                        slideOutOfContainer(
                            AnimatedContentTransitionScope.SlideDirection.Left,
                            animationSpec = tween(500)
                        )
                    }
                ) {
                    TouchTestScreen(navController)
                }

                composable(
                    Screen.Proximity.route,
                    enterTransition = {
                        slideIntoContainer(
                            AnimatedContentTransitionScope.SlideDirection.Right,
                            animationSpec = tween(500)
                        )
                    },
                    exitTransition = {
                        slideOutOfContainer(
                            AnimatedContentTransitionScope.SlideDirection.Left,
                            animationSpec = tween(500)
                        )
                    }
                ) {
                    ProximityScreen(navController)
                }

                composable(
                    Screen.LightSensor.route,
                    enterTransition = {
                        slideIntoContainer(
                            AnimatedContentTransitionScope.SlideDirection.Right,
                            animationSpec = tween(500)
                        )
                    },
                    exitTransition = {
                        slideOutOfContainer(
                            AnimatedContentTransitionScope.SlideDirection.Left,
                            animationSpec = tween(500)
                        )
                    }
                ) {
                    LightSensorScreen(navController)
                }


                composable(
                    Screen.Bluetooth.route,
                    enterTransition = {
                        slideIntoContainer(
                            AnimatedContentTransitionScope.SlideDirection.Right,
                            animationSpec = tween(500)
                        )
                    },
                    exitTransition = {
                        slideOutOfContainer(
                            AnimatedContentTransitionScope.SlideDirection.Left,
                            animationSpec = tween(500)
                        )
                    }
                ) {
                    BluetoothScreen(navController)
                }


                composable(
                    Screen.Biometric.route,
                    enterTransition = {
                        slideIntoContainer(
                            AnimatedContentTransitionScope.SlideDirection.Right,
                            animationSpec = tween(500)
                        )
                    },
                    exitTransition = {
                        slideOutOfContainer(
                            AnimatedContentTransitionScope.SlideDirection.Left,
                            animationSpec = tween(500)
                        )
                    }
                ) {
                    BiometricAuthentication()
                }
                composable(
                    Screen.MicroPhoneT.route,
                    enterTransition = {
                        slideIntoContainer(
                            AnimatedContentTransitionScope.SlideDirection.Right,
                            animationSpec = tween(500)
                        )
                    },
                    exitTransition = {
                        slideOutOfContainer(
                            AnimatedContentTransitionScope.SlideDirection.Left,
                            animationSpec = tween(500)
                        )
                    }
                ) {
                    MicrophoneTestScreen(navController)
                }
                composable(
                    Screen.SensorT.route,
                    enterTransition = {
                        slideIntoContainer(
                            AnimatedContentTransitionScope.SlideDirection.Right,
                            animationSpec = tween(500)
                        )
                    },
                    exitTransition = {
                        slideOutOfContainer(
                            AnimatedContentTransitionScope.SlideDirection.Left,
                            animationSpec = tween(500)
                        )
                    }
                ) {
                    SensorTestScreen(navController)
                }
                composable(
                    Screen.VibrateT.route,
                    enterTransition = {
                        slideIntoContainer(
                            AnimatedContentTransitionScope.SlideDirection.Right,
                            animationSpec = tween(500)
                        )
                    },
                    exitTransition = {
                        slideOutOfContainer(
                            AnimatedContentTransitionScope.SlideDirection.Left,
                            animationSpec = tween(500)
                        )
                    }
                ) {
                    VibrationTestScreen(navController)
                }

                composable(
                    Screen.AppListT.route,
                    enterTransition = {
                        slideIntoContainer(
                            AnimatedContentTransitionScope.SlideDirection.Right,
                            animationSpec = tween(500)
                        )
                    },
                    exitTransition = {
                        slideOutOfContainer(
                            AnimatedContentTransitionScope.SlideDirection.Left,
                            animationSpec = tween(500)
                        )
                    }
                ) {
                    SystemAppLoaderScreen(navController)
                }
                composable(
                    Screen.SpeedTestT.route,
                    enterTransition = {
                        slideIntoContainer(
                            AnimatedContentTransitionScope.SlideDirection.Right,
                            animationSpec = tween(500)
                        )
                    },
                    exitTransition = {
                        slideOutOfContainer(
                            AnimatedContentTransitionScope.SlideDirection.Left,
                            animationSpec = tween(500)
                        )
                    }
                ) {
                    MySpeedTestScreen(navController)
                }
                composable(
                    Screen.HistoryT.route,
                    enterTransition = {
                        slideIntoContainer(
                            AnimatedContentTransitionScope.SlideDirection.Right,
                            animationSpec = tween(500)
                        )
                    },
                    exitTransition = {
                        slideOutOfContainer(
                            AnimatedContentTransitionScope.SlideDirection.Left,
                            animationSpec = tween(500)
                        )
                    }
                ) {
                    HistoryScreen(onBack = { navController.popBackStack() })
                }

            }
        }
    }
}}
