package com.pixeldev.composys.infoScreen

import android.content.Context
import android.content.pm.PackageManager
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Check
import androidx.compose.material.icons.filled.Close
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.remember
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.navigation.NavHostController
import com.pixeldev.composys.utlis.CommonScaffold

@Composable
fun DeviceFeaturesScreen(navHostController: NavHostController) {
    CommonScaffold(
        title = "Device Features",
        onBackClick = { navHostController.popBackStack() }) { padding ->

        val context = LocalContext.current
        val features = remember { getAllPhoneFeatures(context) }

        LazyColumn(modifier = Modifier.padding(padding).padding(16.dp)) {
            items(features.size) { feature ->
                FeatureCard(features[feature])
            }
        }
    }
}
@Composable
fun FeatureCard(feature: PhoneFeature) {
    Card(
        modifier = Modifier
            .fillMaxWidth()
            .padding(vertical = 4.dp),
        colors = CardDefaults.cardColors(containerColor = Color(0xffFDE598).copy(alpha = 0.1f)),
        border = BorderStroke(2.dp, Color(0xffFDE598).copy(alpha = 0.7f)),
        shape = RoundedCornerShape(12.dp),
        elevation = CardDefaults.cardElevation(defaultElevation = 0.dp)
    ) {
        Row(
            modifier = Modifier
                .padding(16.dp)
                .fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween
        ) {
            Text(text = feature.name, fontWeight = FontWeight.Medium)
            Icon(
                imageVector = if (feature.isSupported) Icons.Default.Check else Icons.Default.Close,
                contentDescription = if (feature.isSupported) "Supported" else "Not supported",
                tint = if (feature.isSupported) Color(0xff53b175) else Color.Red
            )
        }
    }
}



data class PhoneFeature(
    val name: String,
    val isSupported: Boolean
)
fun getAllPhoneFeatures(context: Context): List<PhoneFeature> {
    val pm = context.packageManager

    val featureMap = listOf(
        "Wi-Fi" to PackageManager.FEATURE_WIFI,
        "Wi-Fi Direct" to PackageManager.FEATURE_WIFI_DIRECT,
        "Wi-Fi 6" to "android.hardware.wifi.6", // Custom
        "Wi-Fi 7" to "android.hardware.wifi.7", // Custom

        "Bluetooth" to PackageManager.FEATURE_BLUETOOTH,
        "Bluetooth LE" to PackageManager.FEATURE_BLUETOOTH_LE,

        "NFC" to PackageManager.FEATURE_NFC,
        "NFC HCE" to PackageManager.FEATURE_NFC_HOST_CARD_EMULATION,

        "NFC" to PackageManager.FEATURE_NFC,
        "NFC HCE" to PackageManager.FEATURE_NFC_HOST_CARD_EMULATION,

        "Ethernet" to PackageManager.FEATURE_ETHERNET,

        "Camera (Any)" to PackageManager.FEATURE_CAMERA_ANY,
        "Front Camera" to PackageManager.FEATURE_CAMERA_FRONT,
        "Autofocus" to PackageManager.FEATURE_CAMERA_AUTOFOCUS,
        "External Camera" to PackageManager.FEATURE_CAMERA_EXTERNAL,
        "Flash" to PackageManager.FEATURE_CAMERA_FLASH,

        "Fingerprint" to PackageManager.FEATURE_FINGERPRINT,
        "Face Authentication" to PackageManager.FEATURE_FACE,
        "Iris Authentication" to PackageManager.FEATURE_IRIS,

        "GPS" to PackageManager.FEATURE_LOCATION_GPS,
        "Network Location" to PackageManager.FEATURE_LOCATION_NETWORK,
        "Location" to PackageManager.FEATURE_LOCATION,
        "Accelerometer" to PackageManager.FEATURE_SENSOR_ACCELEROMETER,
        "Gyroscope" to PackageManager.FEATURE_SENSOR_GYROSCOPE,
        "Compass" to PackageManager.FEATURE_SENSOR_COMPASS,
        "Proximity Sensor" to PackageManager.FEATURE_SENSOR_PROXIMITY,
        "Step Counter" to PackageManager.FEATURE_SENSOR_STEP_COUNTER,
        "Telephony" to PackageManager.FEATURE_TELEPHONY,
        "USB Host" to PackageManager.FEATURE_USB_HOST,
        "USB Accessory" to PackageManager.FEATURE_USB_ACCESSORY,
        "Audio Output" to PackageManager.FEATURE_AUDIO_OUTPUT,
        "Touchscreen" to PackageManager.FEATURE_TOUCHSCREEN,
        "Multi-touch" to PackageManager.FEATURE_TOUCHSCREEN_MULTITOUCH,
        "Live Wallpaper" to PackageManager.FEATURE_LIVE_WALLPAPER,
        "Secondary Display" to PackageManager.FEATURE_ACTIVITIES_ON_SECONDARY_DISPLAYS,
        "Gamepad" to PackageManager.FEATURE_GAMEPAD,
        "SIP VOIP" to PackageManager.FEATURE_SIP_VOIP,
        "GSM" to PackageManager.FEATURE_TELEPHONY_GSM,
        "CDMA" to PackageManager.FEATURE_TELEPHONY_CDMA,
    )

    return featureMap.map { (name, feature) ->
        PhoneFeature(name, pm.hasSystemFeature(feature))
    }
}

