package com.pixeldev.composys.utlis

import android.content.Context
import android.os.Build
import android.provider.Settings
import androidx.annotation.RequiresPermission

object DeviceInfoProvider {

    @RequiresPermission("android.permission.READ_PRIVILEGED_PHONE_STATE")
    fun getDeviceInfo(context: Context): DeviceInfoModel {
        val brand = Build.BRAND
        val manufacturer = Build.MANUFACTURER
        val model = Build.MODEL
        val device = Build.DEVICE
        val product = Build.PRODUCT
        val hardware = Build.HARDWARE
        val board = Build.BOARD
        val user = Build.USER
        val androidVersion = Build.VERSION.RELEASE
        val sdkInt = Build.VERSION.SDK_INT
        val androidId = Settings.Secure.getString(context.contentResolver, Settings.Secure.ANDROID_ID)
        // Serial is restricted on Android 10+
        val serial = try {
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
                Build.getSerial()
            } else {
                @Suppress("DEPRECATION")
                Build.SERIAL
            }
        } catch (e: SecurityException) {
            "Permission Denied"
        } catch (e: Exception) {
            "Unavailable"
        }

        return DeviceInfoModel(
            brand,
            manufacturer,
            model,
            device,
            product,
            hardware,
            board,
            serial,
            user,
            androidVersion,
            sdkInt,
            androidId
        )
    }
}
