package com.pixeldev.composys.testingScreen.speedTest

import android.app.Application
import dagger.Module
import dagger.Provides
import dagger.hilt.InstallIn
import dagger.hilt.components.SingletonComponent
import javax.inject.Singleton

@Module
@InstallIn(SingletonComponent::class)
object AppModule {
    @Singleton
    @Provides
    fun provideSpeedTestDataStore(app: Application): SpeedTestDataStore {
        return SpeedTestDataStore(app)
    }
}
