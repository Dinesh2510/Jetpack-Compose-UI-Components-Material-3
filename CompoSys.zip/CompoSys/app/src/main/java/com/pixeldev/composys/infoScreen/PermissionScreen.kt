package com.pixeldev.composys.infoScreen
import android.app.Activity
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.padding
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.dp

import androidx.compose.material3.TextButton
import androidx.compose.runtime.mutableStateListOf
import androidx.navigation.NavHostController
import com.pixeldev.composys.Screen
import com.pixeldev.composys.utlis.PermissionManager

@Composable
fun PermissionScreen(navController: NavHostController) {
    val context = LocalContext.current
    val activity = context as Activity

    val permissions = remember { PermissionManager.getPermissions().toTypedArray() }

    val showDialog = remember { mutableStateOf(false) }
    val deniedPermissions = remember { mutableStateListOf<String>() }

    val launcher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.RequestMultiplePermissions()
    ) { result ->
        deniedPermissions.clear()
        PermissionManager.logPermissionsResult(result)
        result.forEach { (perm, granted) ->
            if (!granted) deniedPermissions.add(perm)
        }
        if (deniedPermissions.isEmpty()) {
            // ✅ Navigate if all granted
            navController.navigate("success")
        } else {
            showDialog.value = true
        }
    }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .padding(24.dp),
        verticalArrangement = Arrangement.Center,
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        Button(onClick = {
            if (PermissionManager.areAllPermissionsGranted(context)) {
                navController.navigate(Screen.Onboarding)
            } else {
                launcher.launch(permissions)
            }
        }) {
            Text("Request Permissions")
        }

        if (showDialog.value) {
            AlertDialog(
                onDismissRequest = {},
                title = { Text("Permissions Required") },
                text = {
                    Text("App needs these permissions:\n${deniedPermissions.joinToString("\n")}")
                },
                confirmButton = {
                    TextButton(onClick = {
                        showDialog.value = false
                        launcher.launch(permissions)
                    }) {
                        Text("Try Again")
                    }
                },
                dismissButton = {
                    TextButton(onClick = {
                        showDialog.value = false
                    }) {
                        Text("Cancel")
                    }
                }
            )
        }
    }
}
