package com.pixeldev.composys.testingScreen

import android.content.Context
import android.hardware.Sensor
import android.hardware.SensorEvent
import android.hardware.SensorEventListener
import android.hardware.SensorManager
import androidx.compose.animation.animateColorAsState
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.tween
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.scale
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.navigation.NavHostController
import com.pixeldev.composys.utlis.CommonScaffold
@Composable
fun ProximityScreen(navController: NavHostController) {
    val ctx = LocalContext.current
    val sensorManager = ctx.getSystemService(Context.SENSOR_SERVICE) as SensorManager
    val proximitySensor = sensorManager.getDefaultSensor(Sensor.TYPE_PROXIMITY)
    val sensorStatus = remember { mutableStateOf("Away") }

    // Animated values for visual effect
    val backgroundColor by animateColorAsState(
        targetValue = if (sensorStatus.value == "Near") Color.Red else Color.Green,
        animationSpec = tween(durationMillis = 300),
        label = "bgColorAnim"
    )
    val scale by animateFloatAsState(
        targetValue = if (sensorStatus.value == "Near") 1.2f else 1f,
        animationSpec = tween(durationMillis = 300),
        label = "scaleAnim"
    )

    val listener = remember {
        object : SensorEventListener {
            override fun onAccuracyChanged(sensor: Sensor, accuracy: Int) {}
            override fun onSensorChanged(event: SensorEvent) {
                if (event.sensor.type == Sensor.TYPE_PROXIMITY) {
                    sensorStatus.value = if (event.values[0] == 0f) "Near" else "Away"
                }
            }
        }
    }

    DisposableEffect(Unit) {
        sensorManager.registerListener(listener, proximitySensor, SensorManager.SENSOR_DELAY_GAME)
        onDispose {
            sensorManager.unregisterListener(listener)
        }
    }

    CommonScaffold(
        title = "Ear Proximity Sensor Test",
        onBackClick = { navController.popBackStack() }
    ) { padding ->
        Box(
            modifier = Modifier
                .fillMaxSize()
                .padding(padding)
                .background(backgroundColor)
               ,
            contentAlignment = Alignment.Center
        ) {
            Column(
                horizontalAlignment = Alignment.CenterHorizontally,
                verticalArrangement = Arrangement.Center,
                modifier = Modifier.scale(scale)
            ) {
                Text("Object is", fontSize = 32.sp, fontWeight = FontWeight.Bold, color = Color.White)
                Spacer(Modifier.height(8.dp))
                Text(sensorStatus.value, fontSize = 40.sp, fontWeight = FontWeight.ExtraBold, color = Color.White)
            }
        }
    }
}