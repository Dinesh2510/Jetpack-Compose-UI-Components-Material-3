package com.pixeldev.composys.utlis

import android.Manifest
import android.app.Activity
import android.app.ActivityManager
import android.content.Context
import android.content.pm.PackageManager
import android.content.res.Configuration
import android.os.Build
import android.os.Environment
import android.os.StatFs
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

import java.io.File
import androidx.annotation.RequiresApi


import android.os.HardwarePropertiesManager
import android.os.PowerManager
import android.telephony.SubscriptionManager
import android.telephony.TelephonyManager
import android.util.DisplayMetrics
import android.util.Log
import android.view.Display
import android.view.WindowManager
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.material3.Scaffold
import androidx.compose.runtime.Composable
import androidx.core.app.ActivityCompat
import kotlin.math.sqrt

object Constant {
    fun getAndroidVersionName(sdkInt: Int): String {
        return when (sdkInt) {
            36 -> "Baklava (Android 16)"    // Developer preview name for Android 14
            35 -> "Vanilla Ice Cream"    // Developer preview name for Android 14
            34 -> "UpsideDownCake (Android 14)"    // Developer preview name for Android 14
            33 -> "Tiramisu (Android 13)"
            32 -> "Snow Cone (Android 12L)"
            31 -> "S (Android 12)"
            30 -> "R (Android 11)"
            29 -> "Q (Android 10)"
            28 -> "Pie (Android 9)"
            27 -> "Oreo MR1 (Android 8.1)"
            26 -> "Oreo (Android 8.0)"
            25 -> "Nougat MR1 (Android 7.1)"
            24 -> "Nougat (Android 7.0)"
            23 -> "Marshmallow (Android 6.0)"
            22 -> "Lollipop MR1 (Android 5.1)"
            21 -> "Lollipop (Android 5.0)"
            20 -> "KitKat Watch (Android 4.4W)"
            19 -> "KitKat (Android 4.4)"
            18 -> "Jelly Bean MR2 (Android 4.3)"
            17 -> "Jelly Bean MR1 (Android 4.2)"
            16 -> "Jelly Bean (Android 4.1)"
            else -> "Unknown"
        }
    }

    fun getBuildTime(): String {
        val buildTimeMillis = Build.TIME
        val sdf = SimpleDateFormat("yyyy-MM-dd HH:mm:ss", Locale.getDefault())
        return sdf.format(Date(buildTimeMillis))
    }

    fun getTotalRAM(context: Context): Long {
        val activityManager = context.getSystemService(Context.ACTIVITY_SERVICE) as ActivityManager
        val memInfo = ActivityManager.MemoryInfo()
        activityManager.getMemoryInfo(memInfo)
        return memInfo.totalMem  // bytes
    }

    fun getTotalStorage(): Long {
        val path = Environment.getDataDirectory()  // internal storage root
        val stat = StatFs(path.path)
        return stat.blockCountLong * stat.blockSizeLong  // bytes
    }

    fun formatBytes(bytes: Long): String {
        val kb = bytes / 1024f
        val mb = kb / 1024f
        val gb = mb / 1024f

        return when {
            gb >= 1 -> String.format("%.2f GB", gb)
            mb >= 1 -> String.format("%.2f MB", mb)
            kb >= 1 -> String.format("%.2f KB", kb)
            else -> "$bytes bytes"
        }
    }

    data class MemoryInfo(
        val total: Long,
        val used: Long,
        val free: Long,
        val usedPercent: Float
    )

    fun getRamInfo(context: Context): MemoryInfo {
        val activityManager = context.getSystemService(Context.ACTIVITY_SERVICE) as ActivityManager
        val memoryInfo = ActivityManager.MemoryInfo()
        activityManager.getMemoryInfo(memoryInfo)

        val total = memoryInfo.totalMem
        val free = memoryInfo.availMem
        val used = total - free
        val usedPercent = (used.toFloat() / total) * 100f

        return MemoryInfo(total, used, free, usedPercent)
    }

    fun getStorageInfo(path: File): MemoryInfo {
        val stat = StatFs(path.path)
        val blockSize = stat.blockSizeLong
        val total = stat.blockCountLong * blockSize
        val available = stat.availableBlocksLong * blockSize
        val used = total - available
        val usedPercent = (used.toFloat() / total) * 100f

        return MemoryInfo(total, used, available, usedPercent)
    }


    data class ThermalReading(val type: String, val temperature: Float)

    @RequiresApi(Build.VERSION_CODES.Q)
    fun getThermalStatus(context: Context): Int {
        val powerManager = context.getSystemService(Context.POWER_SERVICE) as PowerManager
        return powerManager.currentThermalStatus
    }

    @RequiresApi(Build.VERSION_CODES.N)
    fun getAnyTemperature(context: Context): Float? {
        val hardwareManager =
            context.getSystemService(Context.HARDWARE_PROPERTIES_SERVICE) as? HardwarePropertiesManager
                ?: return null

        val deviceTempTypes = listOf(
            HardwarePropertiesManager.DEVICE_TEMPERATURE_CPU,
            HardwarePropertiesManager.DEVICE_TEMPERATURE_GPU,
            HardwarePropertiesManager.DEVICE_TEMPERATURE_BATTERY,
            HardwarePropertiesManager.DEVICE_TEMPERATURE_SKIN
        )

        for (type in deviceTempTypes) {
            try {
                val temps = hardwareManager.getDeviceTemperatures(
                    type,
                    HardwarePropertiesManager.TEMPERATURE_CURRENT
                )

                if (!temps.isNotEmpty()) {
                    Log.d("ThermalInfo", "Temperature for type $type: ${temps.first()} °C")
                    return temps.first()
                }
            } catch (e: SecurityException) {
                Log.e("ThermalInfo", "No permission to access thermal data")
            } catch (e: Exception) {
                Log.e("ThermalInfo", "Error reading temperature for type $type: ${e.message}")
            }
        }

        Log.w("ThermalInfo", "No readable temperature from HardwarePropertiesManager")

        // 🔁 Fallback: try reading from thermal zones (if rooted or debug mode)
        return tryThermalZoneFallback()
    }

    fun tryThermalZoneFallback(): Float? {
        val zonePaths = listOf(
            "/sys/class/thermal/thermal_zone0/temp",
            "/sys/class/thermal/thermal_zone1/temp",
            "/sys/class/thermal/thermal_zone2/temp"
        )

        for (path in zonePaths) {
            try {
                val file = java.io.File(path)
                if (file.exists()) {
                    val temp = file.readText().trim().toFloatOrNull()
                    if (temp != null) {
                        val normalized = if (temp > 1000f) temp / 1000f else temp
                        Log.d("ThermalInfo", "Fallback temp from $path: $normalized °C")
                        return normalized
                    }
                }
            } catch (e: Exception) {
                Log.e("ThermalInfo", "Error reading $path: ${e.message}")
            }
        }

        return null
    }


    @RequiresApi(Build.VERSION_CODES.R)
    fun getThermalHeadroomThresholds(context: Context): Map<Int, Float> {
        val powerManager = context.getSystemService(Context.POWER_SERVICE) as PowerManager
        return powerManager.thermalHeadroomThresholds
    }

    @RequiresApi(Build.VERSION_CODES.R)
    fun getThermalHeadroom(context: Context): Float? {
        return try {
            val powerManager = context.getSystemService(Context.POWER_SERVICE) as? PowerManager
            powerManager?.getThermalHeadroom(0)
        } catch (e: Exception) {
            e.printStackTrace()
            null
        }
    }

    /*✅ What getThermalHeadroom(int status) Means
    You're supposed to pass a time horizon estimate in seconds:

    0 = current

    1 = estimated thermal headroom 1 second from now

    5 = headroom in 5 seconds, etc.*/
    fun isDeviceRooted(): Boolean {
        // 1. Check build tags for test-keys (usually present on rooted devices)
        val buildTags = android.os.Build.TAGS
        if (buildTags != null && buildTags.contains("test-keys")) {
            return true
        }

        // 2. Check for existence of su binary in common locations
        val paths = arrayOf(
            "/system/app/Superuser.apk",
            "/sbin/su",
            "/system/bin/su",
            "/system/xbin/su",
            "/data/local/xbin/su",
            "/data/local/bin/su",
            "/system/sd/xbin/su",
            "/system/bin/failsafe/su",
            "/data/local/su"
        )
        for (path in paths) {
            if (java.io.File(path).exists()) {
                return true
            }
        }

        // 3. Try executing su command (optional, can be slow or blocked)
        return try {
            val process = Runtime.getRuntime().exec(arrayOf("/system/xbin/which", "su"))
            val bufferedReader = process.inputStream.bufferedReader()
            val output = bufferedReader.readLine()
            output != null
        } catch (e: Exception) {
            false
        }
    }

    data class SimInfo(
        val carrierName: String?,
        val displayName: String?,
        val countryIso: String?,
        val simSlotIndex: Int,
        val subscriptionId: Int,
        val isRoaming: Boolean,
        val phoneNumber: String?,
        val isActive: Boolean
    )

    fun getSimInfoList(context: Context): List<SimInfo> {
        val simInfoList = mutableListOf<SimInfo>()

        val subscriptionManager = context.getSystemService(Context.TELEPHONY_SUBSCRIPTION_SERVICE) as? SubscriptionManager
        val telephonyManager = context.getSystemService(Context.TELEPHONY_SERVICE) as? TelephonyManager

        if (ActivityCompat.checkSelfPermission(context, Manifest.permission.READ_PHONE_STATE) != PackageManager.PERMISSION_GRANTED) {
            Log.w("SimInfo", "READ_PHONE_STATE permission not granted.")
            return simInfoList
        }

        val subscriptionInfoList = subscriptionManager?.activeSubscriptionInfoList
        if (!subscriptionInfoList.isNullOrEmpty()) {
            for (info in subscriptionInfoList) {
                val subId = info.subscriptionId
                val tmForSub = telephonyManager?.createForSubscriptionId(subId)

                // Optional: you can get simState if needed
                val simSlotIndex = info.simSlotIndex
                val simState = telephonyManager?.getSimState(simSlotIndex)
                val isSimReady = simState == TelephonyManager.SIM_STATE_READY

                simInfoList.add(
                    SimInfo(
                        carrierName = info.carrierName?.toString(),
                        displayName = info.displayName?.toString(),
                        countryIso = info.countryIso,
                        simSlotIndex = simSlotIndex,
                        subscriptionId = subId,
                        isRoaming = tmForSub?.isNetworkRoaming ?: false,
                        phoneNumber = tmForSub?.line1Number,
                        isActive = isSimReady
                    )
                )
            }
        } else {
            Log.w("SimInfo", "No active SIM found.")
        }

        return simInfoList
    }



}
fun getFullDisplayInfo(context: Context): FullDisplayInfo {
    val wm = context.getSystemService(Context.WINDOW_SERVICE) as WindowManager
    val display = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.R) {
        context.display
    } else {
        @Suppress("DEPRECATION")
        wm.defaultDisplay
    }

    val metrics = DisplayMetrics()
    val realMetrics = DisplayMetrics()

    if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.R) {
        context.display?.getRealMetrics(realMetrics)
        context.display?.getMetrics(metrics)
    } else {
        @Suppress("DEPRECATION")
        wm.defaultDisplay.getMetrics(metrics)
        @Suppress("DEPRECATION")
        wm.defaultDisplay.getRealMetrics(realMetrics)
    }

    val config = context.resources.configuration

    // Calculate physical screen size in inches
    val widthInches = realMetrics.widthPixels / realMetrics.xdpi
    val heightInches = realMetrics.heightPixels / realMetrics.ydpi
    val diagonalInches = sqrt(widthInches * widthInches + heightInches * heightInches)

    val densityBucket = when (metrics.densityDpi) {
        in 0..160 -> "mdpi"
        in 161..240 -> "hdpi"
        in 241..320 -> "xhdpi"
        in 321..480 -> "xxhdpi"
        in 481..640 -> "xxxhdpi"
        else -> "unknown"
    }

    return FullDisplayInfo(
        screenWidthPx = metrics.widthPixels,
        screenHeightPx = metrics.heightPixels,
        realWidthPx = realMetrics.widthPixels,
        realHeightPx = realMetrics.heightPixels,
        xdpi = metrics.xdpi,
        ydpi = metrics.ydpi,
        densityDpi = metrics.densityDpi,
        densityBucket = densityBucket,
        density = metrics.density,
        scaledDensity = metrics.scaledDensity,
        refreshRate = display?.refreshRate ?: 60f,
        screenInches = diagonalInches.toDouble(),
        displayName = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.R) display?.name else null,
        screenWidthDp = config.screenWidthDp,
        screenHeightDp = config.screenHeightDp,
        smallestWidthDp = config.smallestScreenWidthDp
    )
}

data class FullDisplayInfo(
    val screenWidthPx: Int,
    val screenHeightPx: Int,
    val realWidthPx: Int,
    val realHeightPx: Int,
    val xdpi: Float,
    val ydpi: Float,
    val densityDpi: Int,
    val densityBucket: String,
    val density: Float,
    val scaledDensity: Float,
    val refreshRate: Float,
    val screenInches: Double,
    val displayName: String?,
    val screenWidthDp: Int,
    val screenHeightDp: Int,
    val smallestWidthDp: Int
)
data class ExtendedDisplayInfo(
    val baseInfo: FullDisplayInfo,

    val orientation: String,
    val layoutSize: String,
    val hdrTypes: List<String>,
    val hasDisplayCutout: Boolean,
    val isWideColorGamut: Boolean,
    val isDisplaySecure: String,
    val physicalSizeInches: Pair<Double, Double>
)

fun getExtendedDisplayInfo(context: Context): ExtendedDisplayInfo {
    val baseInfo = getFullDisplayInfo(context)
    val config = context.resources.configuration
    val wm = context.getSystemService(Context.WINDOW_SERVICE) as WindowManager

    val display = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.R) {
        context.display
    } else {
        @Suppress("DEPRECATION")
        wm.defaultDisplay
    }

    // Orientation
    val orientation = when (config.orientation) {
        Configuration.ORIENTATION_PORTRAIT -> "Portrait"
        Configuration.ORIENTATION_LANDSCAPE -> "Landscape"
        else -> "Undefined"
    }

    // Layout Size
    val layoutSize = when (config.screenLayout and Configuration.SCREENLAYOUT_SIZE_MASK) {
        Configuration.SCREENLAYOUT_SIZE_SMALL -> "Small"
        Configuration.SCREENLAYOUT_SIZE_NORMAL -> "Normal"
        Configuration.SCREENLAYOUT_SIZE_LARGE -> "Large"
        Configuration.SCREENLAYOUT_SIZE_XLARGE -> "XLarge"
        else -> "Undefined"
    }

    // HDR Types
    val hdrTypes = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.N) {
        val capabilities = display?.hdrCapabilities
        capabilities?.supportedHdrTypes?.map { type ->
            when (type) {
                Display.HdrCapabilities.HDR_TYPE_DOLBY_VISION -> "Dolby Vision"
                Display.HdrCapabilities.HDR_TYPE_HDR10 -> "HDR10"
                Display.HdrCapabilities.HDR_TYPE_HLG -> "HLG"
                Display.HdrCapabilities.HDR_TYPE_HDR10_PLUS -> "HDR10+"
                else -> "Unknown HDR"
            }
        } ?: emptyList()
    } else emptyList()

    // Display Cutout
    val cutoutExists = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.P && context is Activity) {
        val insets = context.window?.decorView?.rootWindowInsets
        val cutout = insets?.displayCutout
        !cutout?.boundingRects.isNullOrEmpty()
    } else false

    // Wide Color Gamut
    val isWideColor = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
        context.display?.isWideColorGamut == true
    } else false

    // Display Secure
    val flags: Int = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.R) {
        context.display?.flags ?: 0
    } else {
        @Suppress("DEPRECATION")
        (context.getSystemService(Context.WINDOW_SERVICE) as WindowManager).defaultDisplay.flags
    }



    return ExtendedDisplayInfo(
        baseInfo = baseInfo,
        orientation = orientation,
        layoutSize = layoutSize,
        hdrTypes = hdrTypes,
        hasDisplayCutout = cutoutExists,
        isWideColorGamut = isWideColor,
        isDisplaySecure = flags.toString(),
        physicalSizeInches = Pair(
            baseInfo.realWidthPx / baseInfo.xdpi.toDouble(),
            baseInfo.realHeightPx / baseInfo.ydpi.toDouble()
        )
    )
}

@Composable
fun CommonScaffold(
    title: String,
    showBackButton: Boolean = true,
    onBackClick: (() -> Unit)? = null,
    content: @Composable (PaddingValues) -> Unit
) {
    Scaffold(
        topBar = {
            CommonToolbar(
                title = title,
                onBackClick = if (showBackButton) {
                    { onBackClick?.invoke() }
                } else null
            )
        },
        content = content
    )
}
