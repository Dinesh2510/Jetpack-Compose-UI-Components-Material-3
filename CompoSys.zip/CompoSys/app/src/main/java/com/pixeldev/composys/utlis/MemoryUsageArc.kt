package com.pixeldev.composys.utlis

import androidx.compose.foundation.Canvas
import androidx.compose.foundation.layout.*
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.pixeldev.composys.utlis.Constant.formatBytes

@Composable
fun MemoryUsageArc(
    label: String,
    percent: Float,
    total: Long,
    used: Long,
    free: Long,
    usedColor: Color = Color(0xff56cef3),
    freeColor: Color = Color(0xfff39a4a),
    modifier: Modifier = Modifier
) {
    /*usedColor: Color = Color(0xffe3f7ec),
    freeColor: Color = Color(0xff21c179),*/
    /* usedColor: Color = Color(0xffe1f5fe),
     freeColor: Color = Color(0xff56cef3),*/
    /*usedColor: Color = Color(0xfffff3e7),
    freeColor: Color = Color(0xfff39a4a),*/
    Box(
        contentAlignment = Alignment.Center,
        modifier = modifier.size(200.dp)
    ) {
        Canvas(modifier = Modifier.fillMaxSize()) {
            val strokeWidth = 80f
            val size = Size(size.width, size.height)

            // Background Arc - Free
            drawArc(
                color = freeColor,
                startAngle = 50f,
                sweepAngle = -280f,
                useCenter = false,
                style = Stroke(strokeWidth, cap = StrokeCap.Round),
                size = size
            )

            // Foreground Arc - Used
            drawArc(
                color = usedColor,
                startAngle = 50f,
                sweepAngle = (percent / 100f) * -280f,
                useCenter = false,
                style = Stroke(strokeWidth, cap = StrokeCap.Round),
                size = size
            )
        }

        Column(
            modifier = Modifier
                .padding(top = 16.dp),
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            // Center % and label
            Text(
                text = "${percent.toInt()}%",
                style = MaterialTheme.typography.bodyLarge.copy(
                    fontSize = 20.sp,
                    textAlign = TextAlign.Center
                )
            )
            Text(
                text = label,
                style = MaterialTheme.typography.bodySmall.copy(
                    fontSize = 14.sp,
                    color = Color.Gray
                )
            )

            Spacer(modifier = Modifier.height(12.dp))

            // Text breakdown
            Column(horizontalAlignment = Alignment.Start) {
                Text("Total: ${formatBytes(total)}", fontSize = 14.sp)
                Text("Used:  ${formatBytes(used)}", fontSize = 14.sp, color = usedColor)
                Text("Free:  ${formatBytes(free)}", fontSize = 14.sp, color = freeColor)
            }
        }
    }
}
