package com.pixeldev.composys.testingScreen.speedTest

import androidx.compose.animation.core.*
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.layout.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.*
import androidx.hilt.navigation.compose.hiltViewModel
import androidx.navigation.NavHostController
import com.pixeldev.composys.DeviceTestGrid
import com.pixeldev.composys.Screen.HistoryT
import com.pixeldev.composys.utlis.CommonScaffold
import kotlin.math.cos
import kotlin.math.sin

@Composable
fun MySpeedTestScreen(navController: NavHostController) {
    CommonScaffold(
        title = "Speed Test - UNDER DEVELOPMENT",
        onBackClick = { navController.popBackStack() }) { padding ->
        SpeedTestScreen(padding, onHistoryClick = { navController.navigate(HistoryT.route) })
    }
}

@Composable
fun SpeedTestScreen(
    paddingValues: PaddingValues,
    onHistoryClick: () -> Unit,
    viewModel: SpeedTestViewModel = hiltViewModel()
) {
    val speed by viewModel.speed.collectAsState()
    val state by viewModel.testRunning.collectAsState()
    var context = LocalContext.current
    Column(
        modifier = Modifier
            .fillMaxSize()
            .padding(paddingValues)
            .padding(16.dp)
    ) {
        // Center the speedometer below the text
        Column(
            modifier = Modifier.fillMaxWidth(),
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            Speedometer(speed)
        }

        // Display the Reset and History buttons
        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceEvenly) {
            Button(onClick = { viewModel.startTest(context) }, enabled = !state) {
                Text("Start Test")
            }
            Button(onClick = viewModel::resetTest) {
                Text("Reset")
            }
            Button(onClick = onHistoryClick) {
                Text("History")
            }
        }
    }
}

@Composable
fun Speedometer(speed: Float) {
    val animatedSpeed by animateFloatAsState(
        targetValue = speed,
        animationSpec = tween(1000), // Smoother transition
        label = "Speed"
    )

    val maxSpeed = 1000f // Representing 1000 Mbps or 1 Gbps
    val angle = animatedSpeed / maxSpeed * 270f

    // Calculate upload speed (80% of download speed)
    val uploadSpeed = animatedSpeed * 0.8f

    // Define the color of the speed arc
    val speedColor = when {
        animatedSpeed < 300 -> Color.Green
        animatedSpeed < 700 -> Color.Yellow
        else -> Color.Red
    }

    Box(contentAlignment = Alignment.Center) {
        Canvas(modifier = Modifier.size(300.dp)) {
            // Draw the outer ring (full circle) representing the max speed
            drawArc(
                color = Color.LightGray,
                startAngle = 135f,
                sweepAngle = 270f,
                useCenter = false,
                style = Stroke(20f)
            )

            // Draw the colored arc (current speed)
            drawArc(
                color = speedColor,
                startAngle = 135f,
                sweepAngle = angle,
                useCenter = false,
                style = Stroke(20f)
            )

            // Draw the needle (indicator) for download speed
            // Needle calculation (sharp and thin)
            val needleAngle = 135f + angle // Calculate the angle based on speed
            val needleLength = 400f  // Shorter length for the needle
            val needleX =
                (size.width / 2) + needleLength * cos(Math.toRadians(needleAngle.toDouble())).toFloat()
            val needleY =
                (size.height / 2) + needleLength * sin(Math.toRadians(needleAngle.toDouble())).toFloat()

            // Draw the needle (sharp and thin line)
            drawLine(
                color = Color.Black,
                start = Offset(size.width / 2, size.height / 2),
                end = Offset(needleX, needleY),
                strokeWidth = 14f  // Smaller stroke width for needle appearance
            )

            // Optionally, add a small circle at the center (base of the needle)
            drawCircle(
                color = Color.Black,
                radius = 25f, // Circle radius at the center
                center = Offset(size.width / 2, size.height / 2)
            )

        }

        // Display the animated speeds (download and upload) in the center
        Column(horizontalAlignment = Alignment.CenterHorizontally) {
            Spacer(modifier = Modifier.height(100.dp))

            // Display download and upload speeds
            Text(
                text = "Download: ${String.format("%.1f", animatedSpeed)} Mbps",
                style = MaterialTheme.typography.bodyMedium.copy(fontWeight = FontWeight.Bold),
                color = Color.Green // Green for download
            )

            Spacer(modifier = Modifier.height(10.dp))

            Text(
                text = "Upload: ${String.format("%.1f", uploadSpeed)} Mbps",
                style = MaterialTheme.typography.bodyMedium.copy(fontWeight = FontWeight.Bold),
                color = Color.Blue // Blue for upload
            )
        }
    }
}
