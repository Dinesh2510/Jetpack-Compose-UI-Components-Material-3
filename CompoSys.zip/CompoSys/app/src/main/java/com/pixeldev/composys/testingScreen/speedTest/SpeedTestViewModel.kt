package com.pixeldev.composys.testingScreen.speedTest

import android.content.Context
import android.net.ConnectivityManager
import android.net.NetworkCapabilities
import android.telephony.TelephonyManager
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import dagger.hilt.android.lifecycle.HiltViewModel
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.*
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.net.URL
import javax.inject.Inject

@HiltViewModel
class SpeedTestViewModel @Inject constructor(
    private val dataStore: SpeedTestDataStore
) : ViewModel() {
    private val _speed = MutableStateFlow(0f)
    val speed: StateFlow<Float> = _speed

    private val _testRunning = MutableStateFlow(false)
    val testRunning: StateFlow<Boolean> = _testRunning

    fun startTest(context: Context) {
        if (_testRunning.value) return
        _testRunning.value = true
        val connectionType = getConnectionType(context)
        viewModelScope.launch {
            _speed.value = 0f
            for (i in 1..20) {
                delay(100)
                _speed.value = (50..1000).random().toFloat()
            }

            val result = SpeedTestResult(
                downloadSpeedMbps = _speed.value,
                uploadSpeedMbps = (_speed.value * 0.8f),
                timestamp = System.currentTimeMillis(),
                connectionType = "5G"
            )
            dataStore.saveResult(result)

            delay(500)
            _testRunning.value = false
        }
    }

    // Function to reset the test and speed state
    fun resetTest() {
        _speed.value = 0f
        _testRunning.value = false
    }

    suspend fun measureDownloadSpeed(): Float {
        return withContext(Dispatchers.IO) {
            try {
                val url = URL("https://speed.hetzner.de/10MB.bin") // test file
                val start = System.currentTimeMillis()
                val connection = url.openConnection()
                connection.connect()

                val input = connection.getInputStream()
                val buffer = ByteArray(8 * 1024)
                var bytesRead: Int
                var totalBytes: Long = 0

                while (input.read(buffer).also { bytesRead = it } != -1) {
                    totalBytes += bytesRead
                }
                input.close()

                val end = System.currentTimeMillis()
                val timeTakenSec = (end - start) / 1000.0
                val mbps = (totalBytes * 8 / 1_000_000.0) / timeTakenSec
                mbps.toFloat()
            } catch (e: Exception) {
                e.printStackTrace()
                0f
            }
        }
    }

    fun getConnectionType(context: Context): String {
        val cm = context.getSystemService(Context.CONNECTIVITY_SERVICE) as ConnectivityManager
        val network = cm.activeNetwork ?: return "No Connection"
        val caps = cm.getNetworkCapabilities(network) ?: return "Unknown"

        return when {
            caps.hasTransport(NetworkCapabilities.TRANSPORT_WIFI) -> "Wi-Fi"
            caps.hasTransport(NetworkCapabilities.TRANSPORT_CELLULAR) -> {
                when (cm.activeNetworkInfo?.subtype) {
                    TelephonyManager.NETWORK_TYPE_LTE -> "4G"
                    TelephonyManager.NETWORK_TYPE_NR -> "5G"
                    TelephonyManager.NETWORK_TYPE_HSPA,
                    TelephonyManager.NETWORK_TYPE_HSPAP,
                    TelephonyManager.NETWORK_TYPE_UMTS -> "3G"
                    else -> "Cellular"
                }
            }
            else -> "Unknown"
        }
    }

}
