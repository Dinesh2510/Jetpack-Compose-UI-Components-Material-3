package com.pixeldev.composys.testingScreen

import android.util.Log
import android.widget.Toast
import androidx.biometric.BiometricManager
import androidx.biometric.BiometricPrompt
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.width
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Fingerprint
import androidx.compose.material3.Button
import androidx.compose.material3.Icon
import androidx.compose.material3.Text

import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.core.content.ContextCompat
import androidx.fragment.app.FragmentActivity
import java.util.concurrent.Executors
@Composable
fun BiometricAuthentication() {
  /*  val context = LocalContext.current
    val activity = remember(context) { context.findFragmentActivity() }*/
    val context = LocalContext.current
    val activity = context.findFragmentActivity()

    var authMessage by remember { mutableStateOf<String?>(null) }
    var canAuthenticate by remember { mutableStateOf(false) }

    // Check biometric capability
    LaunchedEffect(Unit) {
        val biometricManager = BiometricManager.from(context)
        when (biometricManager.canAuthenticate(BiometricManager.Authenticators.BIOMETRIC_STRONG or  BiometricManager.Authenticators.DEVICE_CREDENTIAL)) {
            BiometricManager.BIOMETRIC_SUCCESS -> {
                canAuthenticate = true
                authMessage = "Ready for biometric authentication ✅"
            }
            BiometricManager.BIOMETRIC_ERROR_NO_HARDWARE -> {
                authMessage = "No biometric hardware available ❌"
            }
            BiometricManager.BIOMETRIC_ERROR_HW_UNAVAILABLE -> {
                authMessage = "Biometric hardware unavailable ❌"
            }
            BiometricManager.BIOMETRIC_ERROR_NONE_ENROLLED -> {
                authMessage = "No biometrics enrolled ❌"
            }
            else -> {
                authMessage = "Biometric authentication not supported ❌"
            }
        }
    }

    val executor = remember { ContextCompat.getMainExecutor(context) }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .padding(24.dp),
        horizontalAlignment = Alignment.CenterHorizontally,
        verticalArrangement = Arrangement.Center
    ) {
        Text("Biometric Authentication", fontSize = 22.sp, fontWeight = FontWeight.Bold)
        Spacer(Modifier.height(16.dp))

        Button(
            onClick = {
                if (activity == null) {
                    authMessage = "Biometric prompt failed: Invalid activity context ❌"
                    return@Button
                }

                val prompt = BiometricPrompt(
                    activity,
                    executor,
                    object : BiometricPrompt.AuthenticationCallback() {
                        override fun onAuthenticationError(errorCode: Int, errString: CharSequence) {
                            super.onAuthenticationError(errorCode, errString)
                            authMessage = "Error: $errString ❌"
                        }

                        override fun onAuthenticationSucceeded(result: BiometricPrompt.AuthenticationResult) {
                            super.onAuthenticationSucceeded(result)
                            authMessage = "Authentication succeeded 🎉"
                        }

                        override fun onAuthenticationFailed() {
                            super.onAuthenticationFailed()
                            authMessage = "Authentication failed. Try again ❌"
                        }
                    }
                )

                val promptInfo = BiometricPrompt.PromptInfo.Builder()
                    .setTitle("Biometric Login")
                    .setSubtitle("Log in using your fingerprint or face")
                    .setNegativeButtonText("Cancel")
                    .build()

                prompt.authenticate(promptInfo)
            },
            enabled = canAuthenticate
        ) {
            Icon(Icons.Default.Fingerprint, contentDescription = null)
            Spacer(Modifier.width(8.dp))
            Text("Authenticate")
        }

        Spacer(Modifier.height(24.dp))

        authMessage?.let {
            Text(
                text = it,
                fontSize = 16.sp,
                color = when {
                    it.contains("succeeded") -> Color(0xFF4CAF50)
                    it.contains("Ready") -> Color(0xFF2196F3)
                    else -> Color.Red
                },
                fontWeight = FontWeight.Medium
            )
        }
    }
}
