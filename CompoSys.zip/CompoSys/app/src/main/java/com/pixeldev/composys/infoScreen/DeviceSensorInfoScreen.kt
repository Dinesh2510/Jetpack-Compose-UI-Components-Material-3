package com.pixeldev.composys.infoScreen

import android.content.Context
import android.hardware.Sensor
import android.hardware.SensorManager
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.remember
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.dp
import androidx.navigation.NavHostController
import com.pixeldev.composys.utlis.CommonScaffold

@Composable
fun DeviceSensorInfoScreen(navController: NavHostController) {
    CommonScaffold(
        title = "Sensor Info",
        onBackClick = { navController.popBackStack() }) {
        val context = LocalContext.current
        SensorListScreen(it)
    }
}

@Composable
fun SensorListScreen(values: PaddingValues) {
    val context = LocalContext.current
    val sensorMap = remember { getCategorizedSensors(context) }

    LazyColumn(
        modifier = Modifier
            .fillMaxSize()
            .padding(values)
            .padding(16.dp)
    ) {
        sensorMap.forEach { (category, sensors) ->
            item {
                Text(
                    text = category.displayName,
                    style = MaterialTheme.typography.titleLarge,
                    modifier = Modifier.padding(vertical = 8.dp)
                )
            }

            items(sensors.size) { sensor ->
                SensorCard(sensor = sensors[sensor])
                Spacer(modifier = Modifier.height(8.dp))
            }
        }
    }
}

@Composable
fun SensorCard(sensor: SensorStatus) {
    Card(
        modifier = Modifier.fillMaxWidth(),
        border = BorderStroke(2.dp, Color(0xFFFFFFFF)),
        elevation = CardDefaults.cardElevation(4.dp),
        colors = CardDefaults.cardColors(
            containerColor = if (sensor.isAvailable) Color(0xFFE8F5E9) else Color(0xFFFFEBEE)
        )
    ) {
        Column(modifier = Modifier.padding(12.dp)) {
            Text(sensor.name, style = MaterialTheme.typography.titleMedium)
            Text("Type: ${sensor.type}")
            Text("Vendor: ${sensor.vendor}")
            Text("Power: ${sensor.power} mA")
            Text("Version: ${sensor.version}")
            Text("Available: ${if (sensor.isAvailable) "✅" else "❌"}")
        }
    }
}

fun getKnownSensorTypesWithCategories(): Map<Int, SensorCategory> = mapOf(
    Sensor.TYPE_ACCELEROMETER to SensorCategory.MOTION,
    Sensor.TYPE_GYROSCOPE to SensorCategory.MOTION,
    Sensor.TYPE_LINEAR_ACCELERATION to SensorCategory.MOTION,
    Sensor.TYPE_GRAVITY to SensorCategory.MOTION,
    Sensor.TYPE_STEP_COUNTER to SensorCategory.MOTION,
    Sensor.TYPE_STEP_DETECTOR to SensorCategory.MOTION,
    Sensor.TYPE_ROTATION_VECTOR to SensorCategory.POSITION,
    Sensor.TYPE_MAGNETIC_FIELD to SensorCategory.POSITION,
    Sensor.TYPE_ORIENTATION to SensorCategory.POSITION,
    Sensor.TYPE_PROXIMITY to SensorCategory.POSITION,
    Sensor.TYPE_LIGHT to SensorCategory.ENVIRONMENT,
    Sensor.TYPE_PRESSURE to SensorCategory.ENVIRONMENT,
    Sensor.TYPE_AMBIENT_TEMPERATURE to SensorCategory.ENVIRONMENT,
    Sensor.TYPE_RELATIVE_HUMIDITY to SensorCategory.ENVIRONMENT,
    Sensor.TYPE_HEART_RATE to SensorCategory.OTHER
)

fun getCategorizedSensors(context: Context): Map<SensorCategory, List<SensorStatus>> {
    val sensorManager = context.getSystemService(Context.SENSOR_SERVICE) as SensorManager
    val availableSensors = sensorManager.getSensorList(Sensor.TYPE_ALL)
    val knownTypes = getKnownSensorTypesWithCategories()

    val sensors = knownTypes.map { (type, category) ->
        val sensor = availableSensors.find { it.type == type }
        SensorStatus(
            type = type,
            name = sensor?.name ?: "Not Supported",
            isAvailable = sensor != null,
            vendor = sensor?.vendor ?: "-",
            power = sensor?.power ?: 0f,
            version = sensor?.version ?: 0,
            category = category
        )
    }

    return sensors.groupBy { it.category }
}

enum class SensorCategory(val displayName: String) {
    MOTION("Motion Sensors"),
    ENVIRONMENT("Environmental Sensors"),
    POSITION("Position Sensors"),
    OTHER("Other Sensors")
}

data class SensorStatus(
    val type: Int,
    val name: String,
    val isAvailable: Boolean,
    val vendor: String,
    val power: Float,
    val version: Int,
    val category: SensorCategory,
    val currentValue: String = ""
)
