package com.pixeldev.composys

import android.app.Activity
import android.content.Intent
import android.net.Uri
import android.widget.Toast
import androidx.activity.compose.BackHandler
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.material3.TopAppBarDefaults
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.dp
import androidx.navigation.NavController

import androidx.compose.material3.CenterAlignedTopAppBar
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.TextButton
import androidx.compose.runtime.mutableStateListOf
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.font.FontWeight
import com.pixeldev.composys.utlis.GridItem
import com.pixeldev.composys.utlis.PermissionManager
import com.pixeldev.composys.utlis.RamUsageSpeedometer
import com.pixeldev.composys.utlis.RotatingFan
import kotlin.collections.component1
import kotlin.collections.component2

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun OnboardingScreen(navController: NavController) {

    val context = LocalContext.current
    var lastBackPressTime by remember { mutableStateOf(0L) }
    val activity = context as Activity
    var speed by remember { mutableStateOf(300f) } // degrees/sec

    val permissions = remember { PermissionManager.getPermissions().toTypedArray() }

    val showDialog = remember { mutableStateOf(false) }
    val deniedPermissions = remember { mutableStateListOf<String>() }

    val launcher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.RequestMultiplePermissions()
    ) { result ->
        deniedPermissions.clear()
        PermissionManager.logPermissionsResult(result)
        result.forEach { (perm, granted) ->
            if (!granted) deniedPermissions.add(perm)
        }
        if (deniedPermissions.isEmpty()) {
            // ✅ Navigate if all granted
            navController.navigate(Screen.Main.route)
        } else {
            showDialog.value = true
        }
    }

    /*top =0xFF25233b bg=0xFF393359 */
    BackHandler {
        val currentTime = System.currentTimeMillis()
        if (currentTime - lastBackPressTime < 2000) {
            (context as? Activity)?.finish()
        } else {
            Toast.makeText(context, "Press back again to exit", Toast.LENGTH_SHORT).show()
            lastBackPressTime = currentTime
        }
    }
    val gradient = Brush.linearGradient(
        colors = listOf( Color(0xFF00A562),Color(0xFF39D66F)),
        start = androidx.compose.ui.geometry.Offset(0f, 0f),
        end = androidx.compose.ui.geometry.Offset(1000f, 1000f)
    )

    Scaffold(
        topBar = {
            CenterAlignedTopAppBar(
                modifier = Modifier.background(gradient), // Apply gradient as background
                title = { Text("Home") },
                colors = TopAppBarDefaults.topAppBarColors(
                    containerColor = Color.Transparent, // Remove solid color since gradient is applied
                    titleContentColor = Color.White
                )
            )
        }
    ) {
        Column(
            modifier = Modifier.padding(it).fillMaxSize(),
            horizontalAlignment = Alignment.CenterHorizontally,
        ) {
           // Spacer(modifier = Modifier.height(20.dp)) // todo : as per screen add top space for meter
            RamUsageSpeedometer()
            Spacer(modifier = Modifier.height(20.dp))

            Text(
                text = stringResource(R.string.app_name),
                style = MaterialTheme.typography.headlineMedium.copy(fontWeight = FontWeight.Bold),
                color = Color.Black,
                modifier = Modifier.padding(8.dp)
            )
            Text(
                text = "Know your phone inside out",
                style = MaterialTheme.typography.bodyMedium,
                color = Color.Black
            )
            Spacer(modifier = Modifier.height(20.dp))

            LazyVerticalGrid(
                columns = GridCells.Fixed(2),
                contentPadding = PaddingValues(16.dp),
                modifier = Modifier.fillMaxSize()
            ) {
                item {

                    GridItem(
                        text = "H/W & S/W Info",
                        imageResId = R.drawable.grid1,
                        bgColor = Color(0xff53b175).copy(alpha = 0.1f),
                        borderColor = Color(0xff53b175).copy(alpha = 0.7f),
                        onClick = {
                            if (PermissionManager.areAllPermissionsGranted(context)) {
                                navController.navigate(Screen.Main.route)
                            } else {
                                launcher.launch(permissions)
                            }
                        }
                    )
                }
                item {
                    GridItem(
                        text = "Test Device",
                        imageResId = R.drawable.tester,
                        bgColor = Color(0xffF7A593).copy(alpha = 0.1f),
                        borderColor = Color(0xffF7A593).copy(alpha = 0.7f),
                        onClick = {
                            navController.navigate(Screen.MainTestScreen.route)
                        }
                    )
                }
                item {
                    GridItem(
                        text = "YouTube Channel",
                        imageResId = R.drawable.yt,
                        bgColor = Color(0xFFDC300C).copy(alpha = 0.1f),
                        borderColor = Color(0xFFDC300C).copy(alpha = 0.7f),
                        onClick = {
                            val youtubeIntent = Intent(Intent.ACTION_VIEW, Uri.parse("https://www.youtube.com/channel/UCu0VgBC3eGjlYL98gYPC1nw"))
                            context.startActivity(youtubeIntent)
                        }
                    )
                }
                item {
                    GridItem(
                        text = "Github Source Code",
                        imageResId = R.drawable.github,
                        bgColor = Color(0xFF000000).copy(alpha = 0.1f),
                        borderColor = Color(0xFF000000).copy(alpha = 0.7f),
                        onClick = {
                            val githubIntent = Intent(Intent.ACTION_VIEW, Uri.parse("https://github.com/Dinesh2510"))
                            context.startActivity(githubIntent)
                        }
                    )
                }
            }
            if (showDialog.value) {
                AlertDialog(
                    onDismissRequest = {},
                    title = { Text("Permissions Required") },
                    text = {
                        Text("App needs these permissions:\n${deniedPermissions.joinToString("\n")}")
                    },
                    confirmButton = {
                        TextButton(onClick = {
                            showDialog.value = false
                            launcher.launch(permissions)
                        }) {
                            Text("Try Again")
                        }
                    },
                    dismissButton = {
                        TextButton(onClick = {
                            showDialog.value = false
                        }) {
                            Text("Cancel")
                        }
                    }
                )
            }
        }
    }


    /* LaunchedEffect(Unit) {
         delay(3000)
         navController.navigate(Screen.Main.route) {
             popUpTo(Screen.Main.route) { inclusive = true }
         }
     }*/
}
