package com.pixeldev.composys.infoScreen

import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.navigation.NavHostController
import com.pixeldev.composys.utlis.CommonScaffold
import com.pixeldev.composys.utlis.Constant.SimInfo
import com.pixeldev.composys.utlis.Constant.getSimInfoList

@Composable
fun SimInfoScreen(navController: NavHostController) {
    CommonScaffold(
        title = "Sim Info",
        onBackClick = { navController.popBackStack() }) {

        val context = LocalContext.current
        var simInfoList by remember { mutableStateOf<List<SimInfo>>(emptyList()) }

        LaunchedEffect(true) {
            simInfoList = getSimInfoList(context)
        }

        Column(Modifier
            .padding(it)
            .padding(16.dp)) {

            if (simInfoList.isEmpty()) {
                Text("No SIM info available", style = MaterialTheme.typography.bodyLarge)
            }

            simInfoList.forEach { sim ->
                Card(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(vertical = 8.dp)
                        .clip(RoundedCornerShape(8.dp)),  // Optional: If you want rounded corners
                    border = BorderStroke(2.dp, Color(0xffB7DFF5)),
                    colors = CardDefaults.cardColors(
                        containerColor = Color(0xffB7DFF5).copy(alpha = 0.25f)
                    ),
                    elevation = CardDefaults.cardElevation(0.dp)  // Increased elevation for more distinct shadow
                ) {
                    Column(Modifier.padding(16.dp)) {
                        Text("SIM Slot: ${sim.simSlotIndex}",fontWeight = FontWeight.Medium,)
                        Text("Carrier: ${sim.carrierName ?: "N/A"}",fontWeight = FontWeight.Medium)
                        Text("Display Name: ${sim.displayName ?: "N/A"}",fontWeight = FontWeight.Medium)
                        Text("Country: ${sim.countryIso ?: "N/A"}",fontWeight = FontWeight.Medium)
                        Text("Phone Number: ${sim.phoneNumber ?: "N/A"}",fontWeight = FontWeight.Medium)
                        Text("Roaming: ${if (sim.isRoaming) "Yes" else "No"}",fontWeight = FontWeight.Medium)
                        Text("Active: ${if (sim.isActive) "Yes" else "No"}",fontWeight = FontWeight.Medium)
                        Text("Subscription ID: ${sim.subscriptionId}",fontWeight = FontWeight.Medium)
                    }
                }
            }
        }
    }
}