package com.pixeldev.composys.model

data class BatteryInfo(
    val level: Int,
    val isCharging: Boolean,
    val chargePlug: String,
    val health: String,
    val temperature: Float,
    val voltage: Int,
    val technology: String
)