package com.pixeldev.composys.testingScreen

import android.widget.Toast
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.navigation.NavHostController
import com.pixeldev.composys.utlis.CommonScaffold

@Composable
fun DisplayTestScreen(navController: NavHostController) {
    val context = LocalContext.current

    val testColors = listOf(
        Color.Red to "Red",
        Color.Green to "Green",
        Color.Blue to "Blue",
        Color.White to "White",
        Color.Black to "Black"
    )

    var currentIndex by remember { mutableStateOf(-1) }

    val isTesting = currentIndex >= 0

    val currentColor = testColors.getOrNull(currentIndex)?.first

    LaunchedEffect(currentIndex) {
        testColors.getOrNull(currentIndex)?.second?.let { colorName ->
            Toast.makeText(context, "Testing $colorName", Toast.LENGTH_SHORT).show()
        }
    }
    CommonScaffold(
        title = "Display Testing",
        onBackClick = { navController!!.popBackStack() }) { padding ->

        Box(
            modifier = Modifier
                .padding(padding)
                .fillMaxSize()
                .background(currentColor ?: MaterialTheme.colorScheme.background)
                .clickable(enabled = isTesting) {
                    if (currentIndex + 1 < testColors.size) {
                        currentIndex += 1
                    } else {
                        currentIndex = -1 // Exit test mode
                    }
                }
        ) {
            if (!isTesting) {
                // Show start button and menu
                Column(
                    modifier = Modifier
                        .fillMaxSize()
                        .padding(16.dp),
                    verticalArrangement = Arrangement.spacedBy(12.dp),
                    horizontalAlignment = Alignment.CenterHorizontally
                ) {
                    Text("Display Test", fontSize = 20.sp, fontWeight = FontWeight.Bold)

                    Button(
                        onClick = { currentIndex = 0 },
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Text("Start Display Test")
                    }

                    Spacer(modifier = Modifier.height(16.dp))

                    Button(
                        onClick = { },
                        colors = ButtonDefaults.buttonColors(containerColor = Color.Gray)
                    ) {
                        Text("Back")
                    }
                }
            }
        }
    }
}