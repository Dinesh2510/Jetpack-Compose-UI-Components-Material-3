package com.pixeldev.composys.testingScreen.speedTest

import kotlinx.serialization.Serializable
import java.util.*

@Serializable
data class SpeedTestResult(
    val id: String = UUID.randomUUID().toString(),
    val downloadSpeedMbps: Float,
    val uploadSpeedMbps: Float,
    val timestamp: Long,
    val connectionType: String // "WiFi", "4G", "5G"
)
