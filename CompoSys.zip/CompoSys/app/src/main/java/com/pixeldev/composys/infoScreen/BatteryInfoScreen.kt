package com.pixeldev.composys.infoScreen

import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.dp
import androidx.navigation.NavHostController
import com.pixeldev.composys.utlis.CommonScaffold
import com.pixeldev.composys.utlis.getBatteryInfo
import kotlinx.coroutines.delay
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.ui.Alignment
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.text.font.FontWeight

@Composable
fun BatteryInfoScreen(navHostController: NavHostController) {

    CommonScaffold(
        title = "Battery Info",
        onBackClick = { navHostController.popBackStack() }
    ) { padding ->

        val context = LocalContext.current
        val batteryInfo = remember { mutableStateOf(getBatteryInfo(context)) }

        // Refresh battery info every 5 seconds
        LaunchedEffect(Unit) {
            while (true) {
                batteryInfo.value = getBatteryInfo(context)
                delay(5000)
            }
        }

        Column(
            modifier = Modifier
                .padding(padding)
                .padding(16.dp)
                .fillMaxSize(),
            verticalArrangement = Arrangement.Top
        ) {
            Card(
                modifier = Modifier.fillMaxWidth(),
                elevation = CardDefaults.cardElevation(defaultElevation = 4.dp),
                colors = CardDefaults.cardColors(
                    containerColor = MaterialTheme.colorScheme.surface
                ),
                border = BorderStroke(2.dp, Color(0xffB7DFF5)),
                shape = RoundedCornerShape(12.dp)
            ) {
                Column(
                    modifier = Modifier.padding(16.dp),
                    verticalArrangement = Arrangement.spacedBy(12.dp)
                ) {
                    BatteryInfoItem(label = "Battery Level", value = "${batteryInfo.value.level}%", icon = Icons.Default.BatteryFull)
                    BatteryInfoItem(label = "Charging", value = if (batteryInfo.value.isCharging) "Yes" else "No", icon = Icons.Default.Power)
                    BatteryInfoItem(label = "Power Source", value = batteryInfo.value.chargePlug, icon = Icons.Default.Cable)
                    BatteryInfoItem(label = "Health", value = batteryInfo.value.health, icon = Icons.Default.Favorite)
                    BatteryInfoItem(label = "Temperature", value = "${batteryInfo.value.temperature} °C", icon = Icons.Default.Thermostat)
                    BatteryInfoItem(label = "Voltage", value = "${batteryInfo.value.voltage} mV", icon = Icons.Default.Bolt)
                    BatteryInfoItem(label = "Technology", value = batteryInfo.value.technology, icon = Icons.Default.Memory)
                }
            }
        }
    }
}
@Composable
fun BatteryInfoItem(label: String, value: String, icon: ImageVector) {
    Row(
        modifier = Modifier.fillMaxWidth(),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Icon(
            imageVector = icon,
            contentDescription = label,
            tint = MaterialTheme.colorScheme.primary,
            modifier = Modifier
                .size(40.dp)
                .padding(end = 12.dp)
        )
        Column {
            Text(
                text = label,
                fontWeight = FontWeight.Medium,
                color = MaterialTheme.colorScheme.onSurfaceVariant
            )
            Text(
                text = value,
                fontWeight = FontWeight.Normal,
                color = MaterialTheme.colorScheme.onSurface
            )
        }
    }
}
