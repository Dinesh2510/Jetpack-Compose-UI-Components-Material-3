package com.app.composepaging.paging

import androidx.paging.PagingSource
import androidx.paging.PagingState
import com.app.composepaging.api.ApiService
import com.app.composepaging.models.PhotoResponse
import kotlinx.coroutines.delay

class UnsplashPagingSource(private val api: ApiService) : PagingSource<Int, PhotoResponse>() {
    override suspend fun load(params: LoadParams<Int>): LoadResult<Int, PhotoResponse> {
        val page = params.key ?: 1
        delay(3000L) // THIS DELAY ADDED FOR TESTING PURPOSE
        return try {
            val response = api.getPhotos(page, params.loadSize)
            LoadResult.Page(
                data = response,
                prevKey = if (page == 1) null else page - 1,
                nextKey = if (response.isEmpty()) null else page + 1
            )
        } catch (exception: Exception) {
            LoadResult.Error(exception)
        }
    }

    override fun getRefreshKey(state: PagingState<Int, PhotoResponse>): Int? {
        return state.anchorPosition?.let { anchorPosition ->
            state.closestPageToPosition(anchorPosition)?.prevKey?.plus(1)
                ?: state.closestPageToPosition(anchorPosition)?.nextKey?.minus(1)
        }
    }
}
