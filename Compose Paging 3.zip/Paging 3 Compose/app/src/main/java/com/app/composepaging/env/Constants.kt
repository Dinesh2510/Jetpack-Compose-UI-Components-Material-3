package com.app.composepaging.env

import com.app.composepaging.R


object Constants {
    val BASE_URL: String ="https://api.unsplash.com/"
    const val API_KEY: String = "mys9Ivzk79w6zR_94d1XVsWTjjvBFxq39SLgQaGgPlI"
    var WIDGET_COLOR :Int= R.drawable.default_widget_color

    const val HOME_SCREEN="home_screen"
}