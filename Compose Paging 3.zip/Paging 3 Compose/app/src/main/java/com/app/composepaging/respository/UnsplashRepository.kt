package com.app.composepaging.respository

import androidx.paging.Pager
import androidx.paging.PagingConfig
import androidx.paging.PagingData
import com.app.composepaging.paging.UnsplashPagingSource
import com.app.composepaging.api.ApiService
import com.app.composepaging.models.CategoryResponse
import com.app.composepaging.models.PhotoResponse
import com.app.composepaging.paging.TopicPagingSource
import com.app.composepaging.paging.TopicPhotoPagingSource

import kotlinx.coroutines.flow.Flow

class UnsplashRepository(private val api: ApiService) {
    fun getPhotos(): Flow<PagingData<PhotoResponse>> {
        return Pager(
            config = PagingConfig(
                pageSize = 20,
                enablePlaceholders = false
            ),
            pagingSourceFactory = { UnsplashPagingSource(api) }
        ).flow
    }

    fun getTopicData(): Flow<PagingData<CategoryResponse>> =
        Pager(
            config = PagingConfig(
                pageSize = 5,
                enablePlaceholders = false,
            ),
            pagingSourceFactory = { TopicPagingSource(api) }
        ).flow

    fun getTopicPhotosData(topicId: String): Flow<PagingData<PhotoResponse>> =
        Pager(
            config = PagingConfig(
                initialLoadSize = 15,
                pageSize = 15,
                maxSize = 100,
                prefetchDistance = 5,
                enablePlaceholders = false,
            ),
            pagingSourceFactory = { TopicPhotoPagingSource(api, topicId) }
        ).flow

}
