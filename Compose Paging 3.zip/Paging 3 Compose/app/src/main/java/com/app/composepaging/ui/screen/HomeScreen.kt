package com.app.composepaging.ui.screen

import androidx.compose.foundation.ExperimentalFoundationApi
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.aspectRatio
import androidx.compose.foundation.layout.defaultMinSize
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.staggeredgrid.LazyVerticalStaggeredGrid
import androidx.compose.foundation.lazy.staggeredgrid.StaggeredGridCells
import androidx.compose.foundation.lazy.staggeredgrid.StaggeredGridItemSpan
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.material3.TopAppBar
import androidx.compose.material3.TopAppBarDefaults
import androidx.compose.runtime.Composable
import androidx.compose.runtime.derivedStateOf
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment


import androidx.compose.ui.ExperimentalComposeUiApi
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.painter.Painter
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.font.FontStyle
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.window.Dialog
import androidx.hilt.navigation.compose.hiltViewModel
import androidx.navigation.NavHostController
import androidx.paging.LoadState
import androidx.paging.compose.collectAsLazyPagingItems
import coil.compose.rememberAsyncImagePainter
import coil.compose.rememberImagePainter
import com.app.composepaging.R
import com.app.composepaging.models.PhotoResponse
import com.app.composepaging.respository.UnsplashViewModel
import com.app.composepaging.ui.componets.ErrorItem
import com.app.composepaging.ui.componets.ErrorPhotoItem
import com.app.composepaging.ui.componets.LoadingItem
import com.app.composepaging.ui.componets.LoadingPhotoItem


@OptIn(ExperimentalMaterial3Api::class)
@ExperimentalFoundationApi
@ExperimentalComposeUiApi
@Composable
fun HomeScreen(navController: NavHostController) {
    val LightPrimary = Color(0xFF8f4c38)

    Scaffold(
        topBar = {
            TopAppBar(
                title = { Text(text = stringResource(id = R.string.app_name), fontSize = 20.sp) },
                modifier = Modifier
                    .fillMaxWidth()
                    .background(LightPrimary),
                colors = TopAppBarDefaults.topAppBarColors(containerColor = MaterialTheme.colorScheme.primaryContainer),
            )
        }
    ) { paddingValues ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(paddingValues)
        ) {
            CategoryList()
        }
    }

}

@Composable
fun CategoryList(viewModel: UnsplashViewModel = hiltViewModel()) {
    val categories = viewModel.getTopicsList.collectAsLazyPagingItems()
    var selectedCategory by remember { mutableStateOf("All") }

    LazyRow(
        modifier = Modifier
            .fillMaxWidth()
            .padding(8.dp),
        horizontalArrangement = Arrangement.spacedBy(8.dp)
    ) {
        items(categories.itemCount) { index ->
            CategoryItem(
                category = categories[index]!!.title,
                isSelected = selectedCategory == categories[index]!!.id,
                onClick = { selectedCategory = categories[index]!!.id }
            )
        }

        categories.apply {
            when {
                loadState.refresh is LoadState.Loading -> {
                    item { LoadingItem() }
                }

                loadState.append is LoadState.Loading -> {
                    item { LoadingItem() }
                }

                loadState.refresh is LoadState.Error -> {
                    val e = categories.loadState.refresh as LoadState.Error
                    item { ErrorItem(message = e.error.localizedMessage!!) }
                }

                loadState.append is LoadState.Error -> {
                    val e = categories.loadState.append as LoadState.Error
                    item { ErrorItem(message = e.error.localizedMessage!!) }
                }
            }
        }
    }
    PhotoListScreen(topicId = selectedCategory)

}


@Composable
fun CategoryItem(category: String, isSelected: Boolean, onClick: () -> Unit) {
    val backgroundColor = if (isSelected) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.primaryContainer
    val textColor = if (isSelected) Color.White else Color.Black

    Box(
        modifier = Modifier
            .clickable(onClick = onClick)
            .background(color = backgroundColor, shape = MaterialTheme.shapes.small)
            .padding(horizontal = 16.dp, vertical = 8.dp)
    ) {
        Text(
            text = category,
            color = textColor,
            fontSize = 16.sp,
            fontWeight = FontWeight.Medium
        )
    }
}

@OptIn(ExperimentalFoundationApi::class)
@Composable
fun PhotoListScreen(viewModel: UnsplashViewModel = hiltViewModel(), topicId: String) {

    val photosFlow by remember(viewModel, topicId) {
        derivedStateOf {
            if (topicId == "All") {
                viewModel.getPhotos()
            } else {
                viewModel.topicWisePics(topicId)
            }
        }
    }

    val photos = photosFlow.collectAsLazyPagingItems()

    LazyVerticalStaggeredGrid(
        verticalItemSpacing = 8.dp,
        horizontalArrangement = Arrangement.spacedBy(8.dp),
        modifier = Modifier
            .fillMaxSize()
            .padding(8.dp),
        columns = StaggeredGridCells.Fixed(2)
    ) {
        items(photos.itemCount) { index ->
            UnsplashImageStaggered(
                modifier = Modifier,
                photos[index]
            )
        }

        photos.apply {
            when {
                loadState.refresh is LoadState.Loading -> {
                    item(span = StaggeredGridItemSpan.FullLine) {
                        LoadingPhotoItem()
                    }
                }

                loadState.append is LoadState.Loading -> {
                    item(span = StaggeredGridItemSpan.FullLine) {
                        LoadingPhotoItem()
                    }
                }

                loadState.refresh is LoadState.Error -> {
                    val e = photos.loadState.refresh as LoadState.Error
                    item(span = StaggeredGridItemSpan.FullLine) {
                        ErrorPhotoItem(e)
                    }
                }

                loadState.append is LoadState.Error -> {
                    val e = photos.loadState.append as LoadState.Error
                    item(span = StaggeredGridItemSpan.FullLine) {
                        ErrorPhotoItem(e)
                    }
                }
            }
        }

    }


}

@ExperimentalFoundationApi
@Composable
private fun UnsplashImageStaggered(
    modifier: Modifier,
    data: PhotoResponse?,
) {
    var showDialog by remember { mutableStateOf(false) }
    var selectedPhoto by remember { mutableStateOf<PhotoResponse?>(null) }


    var isLoading by remember { mutableStateOf(true) }
    val aspectRatio: Float by remember {
        derivedStateOf { (data?.width?.toFloat() ?: 1.0F) / (data?.height?.toFloat() ?: 1.0F) }
    }
    val context = LocalContext.current
    val painter: Painter = rememberImagePainter(
        request = coil.request.ImageRequest.Builder(context)
            .data(data?.urls?.small)
            .listener(
                onStart = { isLoading = true },
                onSuccess = { _, _ -> isLoading = false },
                onError = { _, _ -> isLoading = false }
            )
            .build()
    )
    Card(
        elevation = CardDefaults.cardElevation(
            defaultElevation = 8.dp
        ),
        shape = RoundedCornerShape(10.dp),
        modifier = Modifier
            .fillMaxWidth(),
        onClick = {
            selectedPhoto = data  // Set the selected photo to show in the dialog
            showDialog = true      // Show the dialog
        }

    ) {
        Box(modifier = Modifier.fillMaxSize()) {
            Image(
                painter = painter,
                contentDescription = data?.description,
                contentScale = ContentScale.FillBounds,
                modifier = Modifier
                    .aspectRatio(aspectRatio)
                    .fillMaxWidth()
                    .defaultMinSize(minHeight = 200.dp)
            )

            if (isLoading) {
                LoadingPhotoItem()
            }
        }

    }
    if (showDialog && selectedPhoto != null) {
        ImageDialog(
            data = selectedPhoto,
            onDismissRequest = { showDialog = false }
        )
    }

}

@Composable
fun ImageDialog(data: PhotoResponse?, onDismissRequest: () -> Unit) {
    Dialog(onDismissRequest = { onDismissRequest() }) {
        Box(
            modifier = Modifier
                .fillMaxWidth()
                .background(Color.White, shape = RoundedCornerShape(10.dp))
                .padding(16.dp)
        ) {
            Column(
                horizontalAlignment = Alignment.CenterHorizontally,
                modifier = Modifier.fillMaxWidth()
            ) {
                // Image Section
                data?.urls?.small.let { imageUrl ->
                    Image(
                        painter = rememberAsyncImagePainter(imageUrl),
                        contentDescription = "Image",
                        contentScale = ContentScale.Crop,
                        modifier = Modifier
                            .fillMaxWidth()
                            .height(250.dp)
                            .clip(RoundedCornerShape(10.dp))
                    )
                }

                // Spacer between Image and Text
                Spacer(modifier = Modifier.height(16.dp))

                // Description Section
                Text(
                    text = data?.alt_description ?: "No Description",
                    style = MaterialTheme.typography.titleSmall,
                    modifier = Modifier.padding(8.dp),
                    maxLines = 1,
                    overflow = TextOverflow.Ellipsis,
                    softWrap = false,
                    fontStyle = FontStyle.Italic,
                )
            }
        }
    }
}