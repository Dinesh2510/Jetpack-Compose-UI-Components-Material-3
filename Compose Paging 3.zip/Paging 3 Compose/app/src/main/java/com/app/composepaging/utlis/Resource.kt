package com.app.composepaging.utlis

import java.lang.Exception

sealed interface Resource<T> {
    class Loading<T>(): Resource<T>
    class Success<T>(val response: T, val message:String? = null): Resource<T>
    class Failure<T>(val exception: Exception, val message: String): Resource<T>
}