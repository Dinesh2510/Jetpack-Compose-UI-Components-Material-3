package com.app.composepaging

import androidx.compose.foundation.ExperimentalFoundationApi
import androidx.compose.runtime.Composable
import androidx.compose.ui.ExperimentalComposeUiApi
import androidx.navigation.compose.NavHost
import androidx.navigation.compose.composable
import androidx.navigation.compose.rememberNavController
import com.app.composepaging.env.Constants.HOME_SCREEN
import com.app.composepaging.ui.screen.HomeScreen


@OptIn(ExperimentalFoundationApi::class, ExperimentalComposeUiApi::class)
@Composable
fun AppScreen() {

    val navController = rememberNavController()

    NavHost(navController = navController, startDestination = HOME_SCREEN) {

        composable(HOME_SCREEN) { HomeScreen(navController) }

       /* composable(
            route = PhotoScreen.PHOTO_DETAIL.route,
            arguments = listOf(navArgument(ARG_PHOTO_ID) { type = NavType.StringType }),
        ) { PhotoDetailScreenEntryPoint(navController) }*/

    }
}