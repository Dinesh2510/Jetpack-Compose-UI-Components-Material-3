package com.example.myapplication

import android.app.Activity
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.layout.*

import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.ArrowBack
import androidx.compose.material.icons.filled.Menu
import androidx.compose.material.icons.filled.MoreVert
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.dp

import androidx.compose.ui.res.vectorResource
import androidx.compose.ui.tooling.preview.Preview
import com.example.myapplication.includes.IncludeContent
import com.example.myapplication.pages.FavoriteScreen
import com.example.myapplication.pages.HomeScreen
import com.example.myapplication.pages.ProfileScreen

import com.example.myapplication.ui.theme.MyApplicationTheme
import com.google.accompanist.pager.ExperimentalPagerApi

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent {
            MyApplicationTheme {
                ContentListingDemo()
            }
        }
    }

    @OptIn(
        ExperimentalMaterial3Api::class, ExperimentalLayoutApi::class, ExperimentalPagerApi::class
    )
    @Preview(
        showBackground = true, device = "id:pixel_7_pro", showSystemUi = true, name = "First View"
    )
    @Composable
    private fun ContentListingDemo() {

        val act = LocalContext.current as Activity
        var selectedTab by remember {
            mutableStateOf(0)
        }


        val titleAndIcons = listOf(
            "Home" to ImageVector.vectorResource(id = R.drawable.baseline_home_24),
            "Favorite" to ImageVector.vectorResource(id = R.drawable.baseline_favorite_24),
            "Profile" to ImageVector.vectorResource(id = R.drawable.baseline_account_circle_24)

        )
        Scaffold(topBar = {
            Column {
                TopAppBar(title = {
                    Text(text = "Tabs Demo", style = MaterialTheme.typography.titleMedium)
                }, navigationIcon = {
                    IconButton(onClick = { act.finish() }) {
                        Icon(
                            imageVector = Icons.Filled.Menu, contentDescription = ""
                        )
                    }
                }, actions = {
                    IconButton(onClick = { }) {
                        Icon(imageVector = Icons.Filled.MoreVert, contentDescription = "")

                    }
                }, colors = TopAppBarDefaults.smallTopAppBarColors(
                    containerColor = MaterialTheme.colorScheme.surfaceColorAtElevation(3.dp)
                )
                )/*TopBar End*/
                TabRow(
                    selectedTabIndex = selectedTab,
                    containerColor = MaterialTheme.colorScheme.surfaceColorAtElevation(3.dp)
                ) {
                    titleAndIcons.forEachIndexed { index, (title, icon) ->
                        Tab(selected = selectedTab == index,
                            onClick = { selectedTab = index },
                            text = { Text(text = title, maxLines = 2) },
                            icon = { Icon(icon, contentDescription = null) })

                    }

                }


            }
        }, content = { innerPadding ->

            when(selectedTab){
                0 -> HomeScreen(innerPadding = innerPadding)
                1 -> FavoriteScreen(innerPadding = innerPadding)
                2-> ProfileScreen(innerPadding = innerPadding)
            }

        })

    }

}


