package com.app.composestorage.model

data class UserDetails(
    val emailAddress: String = "",
    val mobileNumber: String = "",
    val password: String = "",
    val name: String = "",

)